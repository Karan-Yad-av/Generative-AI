"""
Master Pipeline Runner for Cryptocurrency Volatility Forecasting.
Executes data ingestion, preprocessing, feature engineering, EDA generation,
model training, evaluation, and system verification in a single run.
"""

import sys
import argparse
import logging
from src.data_loader import load_raw_data
from src.preprocessing import clean_and_preprocess
from src.feature_engineering import create_feature_pipeline
from src.generate_eda_plots import generate_all_eda_plots
from src.train import train_pipeline
from src.predict import VolatilityPredictor

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)


def main():
    parser = argparse.ArgumentParser(description="Cryptocurrency Volatility ML Pipeline Runner")
    parser.add_argument("--skip-eda", action="store_true", help="Skip EDA plot generation")
    args = parser.parse_args()

    print("=" * 70)
    print(" CRYPTOCURRENCY VOLATILITY PREDICTION PIPELINE")
    print("=" * 70)

    # Step 1: Ingestion
    logger.info(">>> STEP 1: Ingesting Raw Data...")
    raw_df = load_raw_data()
    print(f"Loaded {len(raw_df):,} raw records.")

    # Step 2: Preprocessing
    logger.info(">>> STEP 2: Preprocessing and Cleaning Data...")
    clean_df = clean_and_preprocess(raw_df)
    print(f"Preprocessed {len(clean_df):,} records across {clean_df['crypto_name'].nunique()} coins.")

    # Step 3: Feature Engineering
    logger.info(">>> STEP 3: Engineering Technical, Volatility, & Liquidity Features...")
    feat_df = create_feature_pipeline(clean_df)
    print(f"Engineered features matrix shape: {feat_df.shape}")

    # Step 4: EDA Generation
    if not args.skip_eda:
        logger.info(">>> STEP 4: Generating Exploratory Visualizations & Statistical Summaries...")
        stats = generate_all_eda_plots()
        print(f"EDA plots saved. Market average volatility: {stats['mean_volatility']:.2f}")

    # Step 5: Training & Evaluation
    logger.info(">>> STEP 5: Training & Evaluating Machine Learning Models...")
    results, best_model_name = train_pipeline()
    print(f"\nTraining complete! Best selected model: {best_model_name}")
    print("\nBenchmark Evaluation Results on Test Set (2022):")
    for m_name, m_data in results.items():
        print(f"  - {m_name:22s} | RMSE: {m_data['test']['RMSE']:.4f} | MAE: {m_data['test']['MAE']:.4f} | R2: {m_data['test']['R2']:.4f}")

    # Step 6: Inference Verification
    logger.info(">>> STEP 6: Validating Model Inference on Live Assets...")
    predictor = VolatilityPredictor()
    test_coins = ["Bitcoin", "Ethereum", "Cardano", "Solana", "Dogecoin"]
    print("\nSample Live Inference Checks:")
    for coin in test_coins:
        try:
            fc = predictor.predict_latest_for_coin(coin)
            print(f"  - {coin:10s}: Price=${fc['close_price']:>10.2f} | Pred 7D Vol={fc['predicted_volatility_pct']:>7s} | Risk={fc['risk_level']}")
        except Exception as e:
            logger.warning("Could not predict for %s: %s", coin, e)

    print("\n" + "=" * 70)
    print(" PIPELINE EXECUTION SUCCESSFUL! All deliverables generated.")
    print("=" * 70)


if __name__ == "__main__":
    main()
