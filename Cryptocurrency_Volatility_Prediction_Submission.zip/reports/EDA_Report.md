# 📊 Exploratory Data Analysis (EDA) Report
## Cryptocurrency Volatility Modeling & Forecasting

**Project Name:** Cryptocurrency Volatility Prediction  
**Dataset:** Historical Daily Cryptocurrency Prices Dataset (55+ Cryptocurrencies, 2013–2022)  
**Total Raw Records:** 72,946  
**Cleaned & Engineered Records:** 71,020  
**Target Variable:** 7-Day Forward Realized Annualized Volatility (\(\sigma_{t, \text{fwd}}\))

---

## 1. Executive Summary & Problem Context

Cryptocurrency markets operate 24 hours a day, 365 days a year, without traditional market closures or circuit breakers. As a consequence, digital asset prices exhibit extreme price dispersion, abrupt regime shifts, and persistent volatility clustering. 

Volatility forecasting in cryptocurrencies is essential for:
1. **Risk Management:** Determining Value-at-Risk (VaR) thresholds and Dynamic Position Sizing.
2. **Derivatives Pricing:** Pricing crypto options, implied volatility surfaces, and funding rate adjustments.
3. **Liquidation Prevention:** Setting algorithmic margin requirements for decentralized finance (DeFi) protocols and centralized exchanges.

This report summarizes empirical findings from our exploratory data analysis across 55 prominent cryptocurrencies over a 9-year span (May 2013 to October 2022).

---

## 2. Dataset Overview & Summary Statistics

### 2.1 Dataset Composition
- **Total Cryptocurrencies:** 55 active assets (after filtering tokens with insufficient trading history).
- **Date Range:** 2013-05-05 to 2022-10-23.
- **Granularity:** Daily OHLCV (Open, High, Low, Close, Trading Volume, Market Capitalization).

### 2.2 Key Statistical Properties
| Metric | Realized 7D Volatility (Annualized) | Daily Log Return | Normalized ATR (%) | Liquidity Ratio (Vol/Cap) |
|---|---|---|---|---|
| **Mean** | 1.0609 (106.1%) | +0.0013 (+0.13%) | 8.88% | 0.2522 |
| **Standard Deviation** | 0.8205 (82.1%) | 0.0828 (8.28%) | 6.41% | 0.7061 |
| **Median (50th %)** | 0.8941 (89.4%) | 0.0000 | 7.15% | 0.0683 |
| **25th Percentile** | 0.5343 (53.4%) | -0.0274 (-2.74%) | 4.62% | 0.0152 |
| **75th Percentile** | 1.3775 (137.8%) | +0.0289 (+2.89%) | 11.23% | 0.2241 |
| **95th Percentile** | 2.6598 (266.0%) | +0.1311 (+13.11%) | 21.84% | 1.0412 |

---

## 3. Visual Explorations & Empirical Insights

### 3.1 Historical Price Trajectories & Market Cycles
The dataset encapsulates multiple four-year crypto market cycles:
- **2013–2015:** The early Bitcoin era and the Mt. Gox collapse.
- **2017–2018:** The ICO boom and subsequent crypto winter.
- **2020–2021:** Institutional adoption, DeFi summer, and historic all-time highs ($69k BTC, $4.8k ETH).
- **2022:** Macro tightening, Terra/Luna crash, and extensive deleveraging.

![Historical Price Trends](figures/eda_price_trends.png)

*Figure 1: Normalized historical price trajectory of major cryptocurrencies on a logarithmic scale.*

---

### 3.2 Volatility Clustering (ARCH / GARCH Effect)
A core stylized fact of financial asset prices is that *large changes tend to be followed by large changes, of either sign, and small changes tend to be followed by small changes* (Mandelbrot, 1963). In cryptocurrencies, this effect is extraordinarily pronounced.

![Volatility Clustering](figures/eda_volatility_clustering.png)

*Figure 2: Daily log returns versus realized and Parkinson volatility for Bitcoin, displaying distinct clustering regimes.*

**Key Takeaways:**
- Periods of low volatility (calm regimes) are frequently punctuated by explosive volatility spikes.
- Volatility spikes decay slowly over time (long memory), validating the utility of rolling multi-window volatility features (7d, 14d, 30d).

---

### 3.3 Return Distributions: Fat Tails and Excess Kurtosis
Unlike traditional asset classes where daily returns approximate a Gaussian normal distribution, cryptocurrency returns exhibit heavy tails (leptokurtosis) and negative skewness during crash regimes.

![Volatility Distribution](figures/eda_volatility_distribution.png)

*Figure 3: Distribution of 7-day forward realized volatility and daily log returns.*

- The daily return distribution has a kurtosis significantly above 3.0, representing severe tail risk ("Black Swan" events).
- The forward realized volatility distribution is strictly positive and right-skewed, with median annualized volatility at 89.4% and an upper 95th percentile reaching 266%.

---

### 3.4 Feature Correlation Analysis
We evaluated cross-correlations between engineered technical indicators and the target 7-day forward realized volatility.

![Feature Correlation Matrix](figures/eda_correlation_matrix.png)

*Figure 4: Pearson correlation matrix of predictive features and forward target volatility.*

**Core Findings:**
1. **Strongest Predictors:** Historical rolling volatilities (`rolling_vol_7d`, `rolling_vol_14d`, `rolling_vol_30d`), Parkinson extreme-range volatility (`parkinson_vol_7d`), and Normalized ATR (`natr_14`) exhibit correlations above **0.65** with future volatility.
2. **Bollinger Bandwidth:** Strongly correlates with volatility expansion (\(r \approx 0.52\)), verifying that band squeeze precedes volatility breakouts.
3. **Liquidity Dynamics:** `liquidity_ratio` (Volume/MarketCap) displays positive correlation with volatility, as sudden influxes in trading turnover accompany volatile price discovery.

---

### 3.5 Liquidity & Market Capitalization Dynamics
Examining the interplay between trading volume, market capitalization, and volatility demonstrates clear liquidity stratification.

![Volume vs Market Cap](figures/eda_volume_vs_marketcap.png)

*Figure 5: Log-volume vs Log-market capitalization colored by forward volatility.*

- **Large-Cap Assets (Bitcoin, Ethereum):** Exhibit deeper liquidity pools, higher market capitalization, and tighter baseline volatility bands (50%–90%).
- **Mid/Small-Cap Tokens:** Exhibit lower liquidity and substantially higher baseline volatility (>120%), making them vulnerable to slippage and liquidity cascades.

---

### 3.6 Volatility Asset Ranking
Comparing annualized volatility across top assets reveals significant heterogeneity across the digital asset ecosystem:

![Crypto Volatility Ranking](figures/eda_crypto_volatility_ranking.png)

*Figure 6: Average realized volatility across top stable vs highly volatile crypto assets.*

- **Most Stable:** Tether (USDT), USD Coin (USDC) maintain standard peg stability (\(\approx 0\%\) volatility); Bitcoin (\(\approx 74\%\)), Ethereum (\(\approx 92\%\)), and Litecoin (\(\approx 94\%\)) form the large-cap baseline.
- **Most Volatile:** Speculative and smaller capitalization assets like Shiba Inu, Dogecoin, Decentraland, and Fantom exhibit average annualized volatilities exceeding 140%–190%.

---

## 4. Implications for Machine Learning Pipeline

1. **Non-Stationarity & Temporal Splitting:** Random k-fold CV causes critical lookahead leakage. A chronological temporal split (Train: 2013–2020, Val: 2021, Test: 2022) is required.
2. **Multiscale Feature Fusion:** Combining moving averages, OHLC range estimators (Parkinson, Garman-Klass), oscillator indicators (RSI), and liquidity ratios provides distinct predictive signals.
3. **Outlier Mitigation:** Clipping target volatility outliers at the 99.5th percentile prevents single exchange anomalies from dominating squared error loss functions.
4. **Model Selection:** Tree-based ensemble architectures (Random Forest and XGBoost) are well suited to capture non-linear interactions between liquidity shocks, band expansions, and volatility regimes.
