"""
Unit Tests for Feature Engineering.
"""

import pytest
import pandas as pd
import numpy as np
from src.feature_engineering import (
    engineer_crypto_features,
    compute_rsi,
    compute_atr,
    FEATURE_COLUMNS,
    TARGET_COLUMN,
)


def test_rsi_bounds():
    prices = pd.Series([10.0, 11.0, 12.0, 11.5, 13.0, 14.0, 13.5, 15.0, 16.0, 17.0, 16.5, 18.0, 19.0, 20.0, 21.0, 22.0])
    rsi = compute_rsi(prices, period=5)
    valid_rsi = rsi.dropna()
    assert (valid_rsi >= 0.0).all() and (valid_rsi <= 100.0).all(), "RSI values must be strictly between 0 and 100."


def test_atr_positive():
    df = pd.DataFrame({
        "close": [10.0, 11.0, 12.0, 11.5, 13.0, 14.0, 13.5, 15.0, 16.0, 17.0, 16.5, 18.0, 19.0, 20.0, 21.0],
        "high": [11.0, 12.0, 13.0, 12.5, 14.0, 15.0, 14.5, 16.0, 17.0, 18.0, 17.5, 19.0, 20.0, 21.0, 22.0],
        "low": [9.0, 10.0, 11.0, 10.5, 12.0, 13.0, 12.5, 14.0, 15.0, 16.0, 15.5, 17.0, 18.0, 19.0, 20.0],
    })
    atr, natr = compute_atr(df, period=5)
    assert (atr.dropna() > 0).all(), "ATR must be strictly positive."
    assert (natr.dropna() > 0).all(), "NATR must be strictly positive."


def test_crypto_feature_columns_and_target():
    dates = pd.date_range("2021-01-01", periods=60)
    df = pd.DataFrame({
        "crypto_name": ["SampleCoin"] * 60,
        "date": dates,
        "open": np.linspace(10, 20, 60),
        "high": np.linspace(12, 22, 60),
        "low": np.linspace(9, 19, 60),
        "close": np.linspace(11, 21, 60),
        "volume": [5000.0] * 60,
        "market_cap": [100000.0] * 60,
    })

    feat = engineer_crypto_features(df, fwd_horizon=7)

    # Check presence of all expected feature columns and target
    for col in FEATURE_COLUMNS:
        assert col in feat.columns, f"Missing feature column: {col}"
    assert TARGET_COLUMN in feat.columns, f"Missing target column: {TARGET_COLUMN}"
