"""
Unit Tests for Model Inference and Risk Engine.
"""

import os
import pytest
import numpy as np
from src.predict import VolatilityPredictor


def test_predictor_initialization():
    predictor = VolatilityPredictor()
    assert predictor.model is not None
    assert len(predictor.feature_columns) > 0


def test_risk_classification():
    predictor = VolatilityPredictor()
    low_risk = predictor.classify_risk(0.35)
    mod_risk = predictor.classify_risk(0.65)
    high_risk = predictor.classify_risk(1.10)
    extreme_risk = predictor.classify_risk(1.80)

    assert low_risk["level"] == "Low"
    assert mod_risk["level"] == "Moderate"
    assert high_risk["level"] == "High"
    assert extreme_risk["level"] == "Extreme"


def test_prediction_output_bounds():
    predictor = VolatilityPredictor()
    # Random synthetic feature matrix
    X_synthetic = np.random.uniform(0.1, 2.0, size=(5, len(predictor.feature_columns)))
    preds = predictor.predict_features(X_synthetic)

    assert len(preds) == 5
    assert (preds > 0).all(), "Volatility predictions must be positive."
