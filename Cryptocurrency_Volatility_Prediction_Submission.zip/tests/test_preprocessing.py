"""
Unit Tests for Data Preprocessing.
"""

import pytest
import pandas as pd
import numpy as np
from src.preprocessing import clean_and_preprocess


def test_clean_and_preprocess_deduplication():
    # Synthetic test DataFrame with duplicates and anomalies
    dates = pd.date_range("2021-01-01", periods=100)
    df = pd.DataFrame({
        "crypto_name": ["TestCoin"] * 100,
        "date": dates,
        "open": np.random.uniform(10, 20, 100),
        "high": np.random.uniform(20, 30, 100),
        "low": np.random.uniform(5, 10, 100),
        "close": np.random.uniform(10, 20, 100),
        "volume": np.random.uniform(1000, 5000, 100),
        "market_cap": np.random.uniform(100000, 500000, 100),
    })

    # Add duplicate row
    dup_row = df.iloc[0:1].copy()
    df_with_dup = pd.concat([df, dup_row], ignore_index=True)

    cleaned = clean_and_preprocess(df_with_dup, min_history_days=50)
    assert len(cleaned) == 100, "Duplicates should be removed."


def test_clean_and_preprocess_ohlc_bounds():
    dates = pd.date_range("2021-01-01", periods=100)
    df = pd.DataFrame({
        "crypto_name": ["TestCoin"] * 100,
        "date": dates,
        "open": [10.0] * 100,
        "high": [5.0] * 100,  # invalid: high < open/close
        "low": [25.0] * 100,  # invalid: low > open/close
        "close": [15.0] * 100,
        "volume": [1000.0] * 100,
        "market_cap": [100000.0] * 100,
    })

    cleaned = clean_and_preprocess(df, min_history_days=50)
    # High must be >= max(open, close)
    assert (cleaned["high"] >= cleaned["open"]).all()
    assert (cleaned["high"] >= cleaned["close"]).all()
    # Low must be <= min(open, close)
    assert (cleaned["low"] <= cleaned["open"]).all()
    assert (cleaned["low"] <= cleaned["close"]).all()


def test_clean_and_preprocess_short_history_filter():
    dates = pd.date_range("2021-01-01", periods=20)
    df = pd.DataFrame({
        "crypto_name": ["ShortCoin"] * 20,
        "date": dates,
        "open": [10.0] * 20,
        "high": [12.0] * 20,
        "low": [8.0] * 20,
        "close": [11.0] * 20,
        "volume": [1000.0] * 20,
        "market_cap": [100000.0] * 20,
    })

    cleaned = clean_and_preprocess(df, min_history_days=50)
    assert len(cleaned) == 0, "Coins with insufficient history should be filtered out."
