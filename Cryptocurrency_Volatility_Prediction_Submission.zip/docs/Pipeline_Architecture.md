# 🔄 Pipeline Architecture & Data Flow Documentation
## Cryptocurrency Volatility Prediction System

---

## 1. End-to-End Pipeline Overview

The **Cryptocurrency Volatility Prediction Pipeline** converts raw daily market prices into production-ready predictive volatility forecasts and actionable operational risk regimes.

The pipeline is organized into distinct execution stages with deterministic reproducibility, zero future lookahead bias, and automated model benchmarking.

```mermaid
flowchart TD
    subgraph 1. Ingestion
        A[dataset.csv / ZIP] --> B[load_raw_data]
        B --> C{Schema Validation}
    end

    subgraph 2. Preprocessing
        C -->|Valid| D[clean_and_preprocess]
        D --> D1[Deduplicate Keys]
        D1 --> D2[Impute Zero/Missing Volume & Cap]
        D2 --> D3[Fix OHLC Physical Bounds]
        D3 --> D4[Filter History < 60 Days]
    end

    subgraph 3. Feature Pipeline
        D4 --> E[engineer_crypto_features]
        E --> E1[Multi-Scale Returns: 1d, 3d, 7d, 14d, 30d]
        E --> E2[Rolling Volatilities: 7d, 14d, 30d]
        E --> E3[Parkinson & Garman-Klass Estimators]
        E --> E4[Bollinger Bands & Normalized ATR]
        E --> E5[Liquidity & Turnover Ratios]
        E --> E6[Target: 7-Day Forward Realized Vol]
    end

    subgraph 4. Modeling & Benchmarking
        E6 --> F[Temporal Splitting]
        F -->|Train: 2013-2020| G1[StandardScaler.fit]
        F -->|Val: 2021| G2[Validation Set]
        F -->|Test: 2022| G3[Test Set]
        G1 --> H[Model Fitting\nRidge | RF | XGBoost]
        H --> I[Model Evaluation on Val & Test]
        I --> J[Champion Selection: Random Forest]
    end

    subgraph 5. Artifact Registry & Serving
        J --> K1[(models/best_volatility_model.pkl)]
        J --> K2[(models/scaler.pkl)]
        J --> K3[(models/model_metrics.json)]
        K1 --> L1[Streamlit Web Dashboard]
        K1 --> L2[Flask RESTful API]
    end
```

---

## 2. Stage-by-Stage Architecture Breakdown

### Stage 1: Ingestion & Schema Standardization
- **Entry Point:** `src/data_loader.py :: load_raw_data()`
- **Input:** `data/raw/dataset.csv` or `data/raw/dataset.csv.zip`
- **Output:** In-memory pandas DataFrame (72,946 records)
- **Validation Controls:**
  - Case-insensitive column resolution (`marketCap` \(\to\) `market_cap`, `crypto_name` \(\to\) `crypto_name`).
  - Strict type verification for all price and volume dimensions.
  - Verification that date timestamps parse without fatal errors.

---

### Stage 2: Data Preprocessing & Boundary Enforcement
- **Entry Point:** `src/preprocessing.py :: clean_and_preprocess()`
- **Input:** Raw standardized DataFrame
- **Output:** Cleaned DataFrame (72,945 records across 55 cryptocurrencies)
- **Guarantees:**
  1. **Strict Monotonicity & No Duplicate Timestamps:** Any duplicated records per crypto and date are removed.
  2. **Physical Market Consistency:** Real-world market bounds require that \(\text{high}_t \ge \max(\text{open}_t, \text{close}_t)\) and \(\text{low}_t \le \min(\text{open}_t, \text{close}_t)\). All records are programmatically bounded.
  3. **Continuity of Liquidity Metrics:** Cryptocurrencies with early zero-volume or unrecorded market capitalization are imputed using forward-backward filling and asset-level medians.
  4. **Warm-up History Assurance:** Currencies with fewer than 60 trading days (e.g. newly listed tokens) are removed to ensure validity of rolling statistical estimators.

---

### Stage 3: Feature Engineering Engine
- **Entry Point:** `src/feature_engineering.py :: create_feature_pipeline()`
- **Input:** Cleaned DataFrame
- **Output:** Feature matrix of 71,020 rows and 28 feature columns + 1 target column
- **Core Signal Groups:**
  - **Temporal Log Returns:** Multi-horizon momentum signals ($1\text{d}, 3\text{d}, 7\text{d}, 14\text{d}, 30\text{d}$).
  - **Rolling Historical Volatility:** Annualized rolling standard deviation of log returns ($7\text{d}, 14\text{d}, 30\text{d}$).
  - **Extreme Range Estimators:** Parkinson High-Low volatility and Garman-Klass OHLC volatility estimators.
  - **Volatility Squeeze & Expansion Indicators:** Bollinger Bandwidth, Bollinger %B, and Normalized Average True Range (NATR-14).
  - **Momentum & Trend:** RSI-14, Normalized MACD, and Price-to-Moving Average ratios ($C/\text{SMA}_7 - 1$, $C/\text{SMA}_{30} - 1$).
  - **Liquidity Shocks:** Turnover velocity ($\text{Volume}/\text{MarketCap}$) and volume-to-7-day moving average spike ratio.
  - **Forward Target:** 7-day forward realized volatility, computed over subsequent dates $t+1 \dots t+7$ and annualized by $\sqrt{365}$.

---

### Stage 4: Temporal Splitting & Leakage Prevention
- **Split Design:**
  - **Training Partition:** Historical dates prior to `2021-01-01` ($N = 48,460$). Captures initial bull and bear market regimes.
  - **Validation Partition:** Dates between `2021-01-01` and `2021-12-31` ($N = 15,225$). Represents the major 2021 bull market and subsequent consolidation.
  - **Test Partition:** Dates on and after `2022-01-01` ($N = 7,335$). Completely unseen out-of-sample data covering the 2022 macro market drawdown.
- **Data Leakage Safeguard:**
  - Standard scaling parameters ($\mu, \sigma$) are computed **strictly from the training set** and applied without re-fitting to validation and test sets.

---

### Stage 5: Model Training, Evaluation & Selection
- **Entry Point:** `src/train.py :: train_pipeline()`
- **Candidate Architectures:**
  1. **Persistence Baseline:** Naive random-walk benchmark predicting $\sigma_{t, \text{fwd}} = \text{rolling\_vol\_7d}_t$.
  2. **Ridge Regression:** L2 regularized linear model.
  3. **XGBoost Regressor:** Gradient boosted decision trees ($250$ estimators, learning rate $0.05$).
  4. **Random Forest Regressor:** Bagging ensemble ($100$ trees, max depth $12$).
- **Selection Criterion:** Minimized RMSE and MAE on the validation set, confirmed on the out-of-time test set.
- **Champion Selected:** **Random Forest Regressor** (Validation RMSE: `0.7555`, Test RMSE: `0.6846`, Test MAE: `0.4581`, Test $R^2$: `0.2346`, Test MAPE: `41.44%`).

---

### Stage 6: Serving & Production Execution
- **Inference Module:** `src/predict.py :: VolatilityPredictor`
  - Loads serialized model and metadata into memory.
  - Exposes sub-10ms scoring methods for both live crypto symbols and arbitrary feature dictionaries.
- **Presentation Layer:**
  - `app/streamlit_app.py`: Rich visual dashboard with asset selectors, interactive scenario sliders, KPI cards, and charts.
  - `app/flask_api.py`: REST API with endpoints `/health`, `/api/cryptos`, `/api/predict/<coin>`, `/api/predict/custom`, `/api/metrics`.

---

## 3. Maintenance, Drift Monitoring & Retraining

In production cryptocurrency environments, models should be refreshed systematically to maintain predictive fidelity:
1. **Retraining Frequency:** Monthly rolling retraining or triggered automatically if 30-day rolling test RMSE increases by $>25\%$.
2. **Concept Drift Detection:** Monitor Kolmogorov-Smirnov (KS) statistic on incoming rolling volatility distributions against the training baseline.
3. **Data Quality Circuit Breaker:** Reject inference payloads with missing critical features or negative price values.
