# ⚙️ Low-Level Design (LLD) Document
## Cryptocurrency Volatility Prediction & Risk Engine

---

## 1. Introduction

This Low-Level Design (LLD) document provides granular technical specifications for the internal classes, mathematical algorithms, data contracts, and implementation logic of the **Cryptocurrency Volatility Prediction System**.

---

## 2. Class & Module Architecture

```mermaid
classDiagram
    class DataLoader {
        +load_raw_data(file_path: str) DataFrame
    }

    class Preprocessor {
        +clean_and_preprocess(df: DataFrame, min_history_days: int) DataFrame
        -impute_crypto_series(group: DataFrame) DataFrame
    }

    class FeatureEngineering {
        +create_feature_pipeline(df: DataFrame, clip_outliers: bool) DataFrame
        +engineer_crypto_features(group: DataFrame, fwd_horizon: int) DataFrame
        +compute_rsi(series: Series, period: int) Series
        +compute_atr(df_group: DataFrame, period: int) Tuple~Series, Series~
    }

    class ModelFactory {
        +get_models(random_state: int) Dict~str, Any~
    }

    class PersistenceBaselineRegressor {
        +rolling_col_idx: int
        +fit(X, y) self
        +predict(X) ndarray
    }

    class ModelTrainer {
        +train_pipeline(data_path: str) Tuple~Dict, str~
    }

    class ModelEvaluator {
        +calculate_metrics(y_true: ndarray, y_pred: ndarray) Dict~str, float~
        +plot_model_comparison(results: Dict, output_path: str)
        +plot_feature_importance(model: Any, feature_names: List, output_path: str)
        +plot_predictions_vs_actual(y_test, y_pred, dates, coin, output_path)
    }

    class VolatilityPredictor {
        +model: Any
        +scaler: StandardScaler
        +feature_columns: List~str~
        +classify_risk(annualized_vol: float) Dict~str, str~
        +predict_features(X) ndarray
        +predict_latest_for_coin(crypto_name: str) Dict~str, Any~
    }

    DataLoader --> Preprocessor : Passes Raw Data
    Preprocessor --> FeatureEngineering : Passes Clean Data
    FeatureEngineering --> ModelTrainer : Supplies Feature Matrix
    ModelFactory --> ModelTrainer : Injects Model Specs
    PersistenceBaselineRegressor --|> ModelFactory
    ModelTrainer --> ModelEvaluator : Validates Performance
    ModelTrainer --> VolatilityPredictor : Exports Serialized Artifacts
```

---

## 3. Detailed Component Specifications

### 3.1 Module: `src/data_loader.py`
- **Function:** `load_raw_data(file_path: Optional[str]) -> pd.DataFrame`
  - **Inputs:** Absolute or relative path to CSV / ZIP dataset.
  - **Outputs:** Clean pandas DataFrame with standardized column names.
  - **Internal Logic:**
    1. If `dataset.csv` does not exist on disk, extracts `dataset.csv.zip`.
    2. Strips whitespace, converts headers to lowercase snake_case (`marketCap` \(\to\) `market_cap`).
    3. Parses dates to `pd.to_datetime`.
    4. Enforces presence of required columns: `open`, `high`, `low`, `close`, `volume`, `market_cap`, `crypto_name`, `date`.
    5. Deterministically sorts records by `crypto_name` ascending and `date` ascending.

---

### 3.2 Module: `src/preprocessing.py`
- **Function:** `clean_and_preprocess(df: pd.DataFrame, min_history_days: int = 60) -> pd.DataFrame`
  - **Inputs:** Raw DataFrame.
  - **Processing Steps:**
    1. **Deduplication:** `df.drop_duplicates(subset=['crypto_name', 'date'])`.
    2. **Close Price Validation:** Discard non-positive or null close prices.
    3. **OHLC Boundary Constraint Enforcement:**
       $$\text{high}_t = \max(\text{high}_t, \text{open}_t, \text{close}_t)$$
       $$\text{low}_t = \min(\text{low}_t, \text{open}_t, \text{close}_t)$$
    4. **Volume & Market Cap Imputation:** Replaces zeros with grouped forward-fill followed by backward-fill and group median.
    5. **History Length Filtering:** Discards newly listed tokens with \(< 60\) days of history to eliminate rolling window instability.

---

### 3.3 Module: `src/feature_engineering.py`

#### Mathematical Formulations:
1. **Daily Log Returns:**
   $$r_t = \ln\left(\frac{C_t}{C_{t-1}}\right)$$

2. **Rolling Realized Volatility (Annualized):**
   $$\sigma_{t, k} = \sqrt{365} \times \sqrt{\frac{1}{k-1} \sum_{i=0}^{k-1} (r_{t-i} - \bar{r})^2}, \quad k \in \{7, 14, 30\}$$

3. **Parkinson Volatility (High-Low Range Estimator):**
   $$\sigma_{P, 7d} = \sqrt{\frac{365}{4 \ln 2 \times 7} \sum_{i=0}^6 \left[\ln\left(\frac{H_{t-i}}{L_{t-i}}\right)\right]^2}$$
   *Advantage:* More efficient than close-to-close volatility as it accounts for intraday price swings.

4. **Garman-Klass Volatility (OHLC Estimator):**
   $$\sigma_{GK, 7d} = \sqrt{\frac{365}{7} \sum_{i=0}^6 \left[ 0.5 \left(\ln\frac{H_{t-i}}{L_{t-i}}\right)^2 - (2\ln 2 - 1)\left(\ln\frac{C_{t-i}}{O_{t-i}}\right)^2 \right]}$$
   *Advantage:* Captures both opening jumps and intraday range dispersion.

5. **Bollinger Bandwidth & %B:**
   $$\text{Middle}_t = \text{SMA}_{20}(C_t), \quad \sigma_{20} = \text{std}_{20}(C_t)$$
   $$\text{Upper}_t = \text{Middle}_t + 2\sigma_{20}, \quad \text{Lower}_t = \text{Middle}_t - 2\sigma_{20}$$
   $$\text{Bandwidth}_t = \frac{\text{Upper}_t - \text{Lower}_t}{\text{Middle}_t}, \quad \%B_t = \frac{C_t - \text{Lower}_t}{\text{Upper}_t - \text{Lower}_t}$$

6. **Average True Range (ATR & NATR):**
   $$\text{TR}_t = \max(H_t - L_t, |H_t - C_{t-1}|, |L_t - C_{t-1}|)$$
   $$\text{ATR}_{14, t} = \text{EMA}_{14}(\text{TR}_t), \quad \text{NATR}_{14, t} = \frac{\text{ATR}_{14, t}}{C_t} \times 100$$

7. **Target Realized Volatility (\(H=7\) days forward):**
   $$Y_t = \sqrt{365} \times \sqrt{\frac{1}{6} \sum_{j=1}^7 (r_{t+j} - \bar{r}_{fwd})^2}$$

---

### 3.4 Module: `src/train.py` & `src/models.py`
- **Data Partitioning (Strict Temporal Cutoffs):**
  - **Train:** \(t < 2021\text{-}01\text{-}01\) (48,460 samples)
  - **Validation:** \(2021\text{-}01\text{-}01 \le t < 2022\text{-}01\text{-}01\) (15,225 samples)
  - **Test:** \(t \ge 2022\text{-}01\text{-}01\) (7,335 samples)
- **Model Hyperparameter Configurations:**
  - `RandomForestRegressor`: `n_estimators=100`, `max_depth=12`, `min_samples_split=20`, `min_samples_leaf=10`, `random_state=42`.
  - `XGBRegressor`: `n_estimators=250`, `learning_rate=0.05`, `max_depth=6`, `subsample=0.8`, `colsample_bytree=0.8`, `reg_alpha=0.1`, `reg_lambda=1.0`.
  - `Ridge`: `alpha=100.0`.
- **Artifact Serialization:**
  - `models/best_volatility_model.pkl`: Serialized champion estimator.
  - `models/scaler.pkl`: Serialized `StandardScaler`.
  - `models/model_metrics.json`: JSON dictionary storing performance scores.
  - `models/feature_metadata.json`: Feature manifest and metadata.

---

### 3.5 Module: `src/predict.py`
- **Class:** `VolatilityPredictor`
  - **Risk Classification Thresholds:**
    - **Low Risk:** \(\sigma < 50\%\) (Color: `#28a745`, Green)
    - **Moderate Risk:** \(50\% \le \sigma < 85\%\) (Color: `#ffc107`, Yellow)
    - **High Risk:** \(85\% \le \sigma < 130\%\) (Color: `#fd7e14`, Orange)
    - **Extreme Risk:** \(\sigma \ge 130\%\) (Color: `#dc3545`, Red)

---

## 4. API & Interface Specifications

### 4.1 REST API Routes (`app/flask_api.py`)
- `GET /health`
  - Response: `{"status": "healthy", "model_type": "Random_Forest", "features_count": 28}`
- `GET /api/cryptos`
  - Response: `{"total_cryptos": 55, "cryptos": ["Aave", "Bitcoin", "Cardano", ...]}`
- `GET /api/predict/<crypto_name>`
  - Response:
    ```json
    {
      "status": "success",
      "data": {
        "crypto_name": "Bitcoin",
        "latest_date": "2022-09-19",
        "close_price": 19544.13,
        "predicted_volatility_annualized": 0.9091,
        "predicted_volatility_pct": "90.91%",
        "risk_level": "High"
      }
    }
    ```
- `POST /api/predict/custom`
  - Request: JSON object with numeric feature key-value pairs.
  - Response: JSON with forecasted volatility and risk regime.
