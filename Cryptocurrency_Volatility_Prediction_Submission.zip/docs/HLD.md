# 🏗️ High-Level Design (HLD) Document
## Cryptocurrency Volatility Prediction & Risk Intelligence System

---

## 1. Introduction & Executive Context

### 1.1 Purpose
The purpose of this High-Level Design (HLD) document is to specify the architectural topology, component boundaries, data flow, and deployment models for the **Cryptocurrency Volatility Prediction System**. 

### 1.2 Business Objectives
1. **Accurate Forecasting:** Anticipate 7-day forward cryptocurrency volatility levels across 55+ digital assets based on historical OHLCV and market capitalization data.
2. **Proactive Risk Mitigation:** Classify market regimes into clear risk tiers (Low, Moderate, High, Extreme) to inform position sizing, Value-at-Risk (VaR), and margin thresholds.
3. **Multi-Channel Delivery:** Deliver real-time predictions via an interactive web dashboard (Streamlit) and a low-latency RESTful API (Flask) for algorithmic trading systems.

---

## 2. System Architecture & Topology

The system is architected as an end-to-end, decoupled machine learning pipeline following clean architecture and modular separation of concerns.

```mermaid
flowchart TD
    subgraph Data Layer
        A1[Historical OHLCV Raw Dataset] --> A2[(Raw Storage / Parquet / CSV)]
    end

    subgraph Data Processing Pipeline
        A2 --> B1[Data Ingestion & Schema Validator]
        B1 --> B2[Data Cleaning & Anomaly Handler]
        B2 --> B3[Feature Engineering Engine]
        B3 --> B4[(Processed Feature Store)]
    end

    subgraph Model & Training Engine
        B4 --> C1[Temporal Time-Series Splitter]
        C1 --> C2[Feature Normalizer & Scaler]
        C2 --> C3[Model Training Engine\nRidge | Random Forest | XGBoost]
        C3 --> C4[Evaluation & Benchmarking Engine]
        C4 --> C5[Model Artifact Store\n.pkl Models & Scalers]
    end

    subgraph Serving & Presentation Layer
        C5 --> D1[Inference Engine / Predictor]
        B4 --> D1
        D1 --> E1[Streamlit Interactive Dashboard]
        D1 --> E2[Flask RESTful Microservice API]
        E2 --> F1[Algorithmic Execution / Trading Systems]
        E1 --> F2[Quantitative Analysts & Portfolio Managers]
    end
```

---

## 3. Component Breakdown

### 3.1 Data Ingestion & Storage Subsystem
- **Source:** Historical cryptocurrency price dataset containing 72,946 daily observations for 55+ cryptocurrencies from 2013 to 2022.
- **Responsibilities:**
  - Standardizes column headers into unified lowercase snake_case format (`date`, `crypto_name`, `open`, `high`, `low`, `close`, `volume`, `market_cap`).
  - Verifies presence of mandatory numeric columns and non-null dates.
  - Implements caching to eliminate redundant disk reads.

### 3.2 Preprocessing & Cleaning Subsystem
- **Responsibilities:**
  - Deduplication across `(crypto_name, date)` keys.
  - Enforces OHLC physical constraints: \(\text{high} \ge \max(\text{open}, \text{close})\) and \(\text{low} \le \min(\text{open}, \text{close})\).
  - Handles missing volume and market capitalization using group-level forward/backward filling and median imputation.
  - Filters out tokens with fewer than 60 trading days to ensure robust rolling windows.

### 3.3 Feature Engineering & Signal Generation Subsystem
- **Responsibilities:**
  - Computes 28 predictive financial signals covering multiple dimensions:
    - **Multi-Horizon Volatilities:** 7-day, 14-day, 30-day rolling standard deviations.
    - **Extreme Range Estimators:** Parkinson Volatility (High-Low) and Garman-Klass Volatility (OHLC).
    - **Moving Averages & Oscillators:** SMA (7, 14, 30), EMA (12, 26), RSI-14, MACD, and Bollinger Bands (%B and Bandwidth).
    - **Liquidity Dynamics:** Turnover ratio (\(\text{Volume}/\text{MarketCap}\)), 7-day volume spike ratio, and log scale transforms.
    - **Target Generation:** Forward 7-day realized annualized volatility:
      $$\sigma_{t, \text{fwd}} = \sqrt{365} \times \text{std}(\ln(C_{t+i}/C_{t+i-1}))_{i=1}^7$$

### 3.4 Model Training & Evaluation Engine
- **Responsibilities:**
  - Enforces **strict temporal ordering** without data leakage:
    - **Train:** 2013-05-05 through 2020-12-31 (Historical bull/bear baseline)
    - **Validation:** 2021-01-01 through 2021-12-31 (Hyperparameter selection on bull market regime)
    - **Test:** 2022-01-01 through 2022-10-23 (Out-of-time evaluation during crypto bear market)
  - Fits baseline models, regularized linear models, Random Forest, and XGBoost.
  - Computes RMSE, MAE, \(R^2\), and MAPE.
  - Automatically selects and serializes the champion model into `models/best_volatility_model.pkl`.

### 3.5 Serving Layer
- **Interactive UI (Streamlit):**
  - Live asset selection with real-time volatility predictions.
  - Risk classification badge (Low, Moderate, High, Extreme).
  - Interactive What-If Scenario Simulator for sensitivity analysis.
  - Historical EDA visual gallery and model diagnostic charts.
- **RESTful API (Flask):**
  - `/health`: Liveness and readiness probes.
  - `/api/cryptos`: Metadata of all available assets.
  - `/api/predict/<coin_name>`: Instant forward volatility prediction and risk categorization.
  - `/api/predict/custom`: Real-time scoring for custom feature payloads.
  - `/api/metrics`: Cross-model benchmark reporting.

---

## 4. Non-Functional Requirements (NFR)

1. **Inference Latency:** Sub-10ms response time per prediction request using cached in-memory model instances.
2. **Scalability:** Horizontal scaling supported for the REST API via stateless containerized deployments.
3. **Data Integrity:** Strict input boundary validation; prevents lookahead bias and division-by-zero errors.
4. **Modularity & Testability:** Decoupled modules with >90% test coverage across data transformation, feature generation, and model inference.

---

## 5. Technology Stack Summary

| Layer | Technology | Rationale |
|---|---|---|
| **Language** | Python 3.10+ / 3.14 | Standard for modern ML and quantitative finance |
| **Data Processing** | Pandas, NumPy, SciPy | Vectorized high-performance numerical operations |
| **Machine Learning** | Scikit-Learn, XGBoost | Battle-tested ensemble algorithms with native multithreading |
| **Visualization** | Matplotlib, Seaborn | High-resolution publication-quality graphics |
| **Dashboard** | Streamlit | Rapid reactive UI prototyping with rich financial charts |
| **Microservice** | Flask | Lightweight, low-overhead RESTful microservice API |
| **Testing** | Pytest | Industry-standard test runner with parameterized test suites |
| **Serialization** | Joblib, JSON | Fast binary object serialization and human-readable metadata |
