"""
Flask REST API for Cryptocurrency Volatility Forecasting.
Provides microservice endpoints for model predictions, batch scoring, and health checks.
"""

import os
import json
import logging
import numpy as np
import pandas as pd
from flask import Flask, request, jsonify

from src.predict import VolatilityPredictor

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

app = Flask(__name__)

# Initialize predictor singleton
predictor = None
try:
    predictor = VolatilityPredictor()
    logger.info("Predictor initialized successfully in Flask API.")
except Exception as e:
    logger.error("Failed to initialize predictor: %s", str(e))


@app.route("/", methods=["GET"])
def index():
    return jsonify({
        "service": "Cryptocurrency Volatility Forecasting API",
        "version": "1.0.0",
        "endpoints": {
            "health": "/health",
            "cryptos": "/api/cryptos",
            "predict_coin": "/api/predict/<coin_name>",
            "predict_custom": "POST /api/predict/custom",
            "metrics": "/api/metrics",
        },
    })


@app.route("/health", methods=["GET"])
def health():
    return jsonify({
        "status": "healthy" if predictor is not None else "degraded",
        "model_loaded": predictor is not None,
        "model_type": predictor.best_model_name if predictor else None,
        "features_count": len(predictor.feature_columns) if predictor else 0,
    })


@app.route("/api/cryptos", methods=["GET"])
def get_cryptos():
    data_path = os.path.join("data", "processed", "crypto_features.csv")
    if not os.path.exists(data_path):
        return jsonify({"error": "Data file not found"}), 404

    df = pd.read_csv(data_path, usecols=["crypto_name"])
    unique_coins = sorted(df["crypto_name"].unique().tolist())
    return jsonify({
        "total_cryptos": len(unique_coins),
        "cryptos": unique_coins,
    })


@app.route("/api/predict/<crypto_name>", methods=["GET"])
def predict_coin(crypto_name: str):
    if predictor is None:
        return jsonify({"error": "Model not loaded"}), 503

    try:
        forecast = predictor.predict_latest_for_coin(crypto_name)
        return jsonify({
            "status": "success",
            "data": forecast,
        })
    except ValueError as ve:
        return jsonify({"error": str(ve)}), 404
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/predict/custom", methods=["POST"])
def predict_custom():
    if predictor is None:
        return jsonify({"error": "Model not loaded"}), 503

    payload = request.get_json(force=True, silent=True)
    if not payload:
        return jsonify({"error": "Invalid or missing JSON payload"}), 400

    try:
        # Fill missing features with default zeros or medians if partial dict provided
        feature_vals = []
        for col in predictor.feature_columns:
            val = payload.get(col, 0.0)
            feature_vals.append(float(val))

        X_input = np.array(feature_vals).reshape(1, -1)
        pred_annualized = float(predictor.predict_features(X_input)[0])
        pred_daily = pred_annualized / np.sqrt(365.0)
        risk = predictor.classify_risk(pred_annualized)

        return jsonify({
            "status": "success",
            "predicted_volatility_annualized": round(pred_annualized, 4),
            "predicted_volatility_pct": f"{pred_annualized * 100:.2f}%",
            "predicted_daily_volatility_pct": f"{pred_daily * 100:.2f}%",
            "risk_level": risk["level"],
            "risk_description": risk["description"],
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@app.route("/api/metrics", methods=["GET"])
def get_metrics():
    metrics_path = os.path.join("models", "model_metrics.json")
    if not os.path.exists(metrics_path):
        return jsonify({"error": "Metrics file not found"}), 404

    with open(metrics_path, "r") as f:
        metrics = json.load(f)
    return jsonify(metrics)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
