"""
Streamlit Web Application: Cryptocurrency Volatility Forecasting & Risk Analytics
"""

import os
import json
import numpy as np
import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt
import seaborn as sns

from src.predict import VolatilityPredictor

# Page configuration
st.set_page_config(
    page_title="Crypto Volatility Intelligence Platform",
    page_icon="⚡",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Custom CSS styling
st.markdown(
    """
    <style>
    .main-header {
        font-size: 2.2rem;
        font-weight: 700;
        color: #1E293B;
        margin-bottom: 0.2rem;
    }
    .sub-header {
        font-size: 1.05rem;
        color: #64748B;
        margin-bottom: 1.5rem;
    }
    .metric-card {
        background-color: #F8FAFC;
        border: 1px solid #E2E8F0;
        border-radius: 10px;
        padding: 1.2rem;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }
    .risk-badge {
        display: inline-block;
        padding: 4px 12px;
        border-radius: 16px;
        font-weight: bold;
        color: white;
    }
    </style>
    """,
    unsafe_allow_html=True,
)


@st.cache_resource
def load_predictor():
    """Cached predictor instance."""
    return VolatilityPredictor()


@st.cache_data
def load_processed_data():
    """Cached processed dataset."""
    data_path = os.path.join("data", "processed", "crypto_features.csv")
    if not os.path.exists(data_path):
        st.error("Processed data file not found! Please run training pipeline first.")
        return None
    df = pd.read_csv(data_path)
    df["date"] = pd.to_datetime(df["date"])
    return df


@st.cache_data
def load_model_metrics():
    """Loads metrics JSON."""
    metrics_path = os.path.join("models", "model_metrics.json")
    if os.path.exists(metrics_path):
        with open(metrics_path, "r") as f:
            return json.load(f)
    return {}


# Main App Execution
def main():
    st.sidebar.image("https://cdn-icons-png.flaticon.com/512/6001/6001368.png", width=60)
    st.sidebar.title("CryptoVol AI")
    st.sidebar.markdown("**Machine Learning Risk Engine**")
    st.sidebar.divider()

    menu = st.sidebar.radio(
        "Navigation",
        [
            "⚡ Real-Time Volatility Forecast",
            "🎛️ Scenario Simulator",
            "📊 Model Benchmarks & Importance",
            "📈 Historical EDA Explorer",
        ],
    )

    df = load_processed_data()
    predictor = load_predictor()
    metrics = load_model_metrics()

    if df is None:
        st.stop()

    available_cryptos = sorted(df["crypto_name"].unique())

    # ---------------------------------------------------------
    # TAB 1: REAL-TIME VOLATILITY FORECAST
    # ---------------------------------------------------------
    if menu == "⚡ Real-Time Volatility Forecast":
        st.markdown('<div class="main-header">⚡ Cryptocurrency Volatility Forecast</div>', unsafe_allow_html=True)
        st.markdown(
            '<div class="sub-header">Anticipate market turbulence and manage crypto portfolio risk with machine learning models.</div>',
            unsafe_allow_html=True,
        )

        col_sel1, col_sel2 = st.columns([2, 1])
        with col_sel1:
            selected_crypto = st.selectbox(
                "Select Cryptocurrency:",
                available_cryptos,
                index=available_cryptos.index("Bitcoin") if "Bitcoin" in available_cryptos else 0,
            )
        with col_sel2:
            st.write("")
            st.write("")
            predict_btn = st.button("🔄 Refresh Forecast", use_container_width=True)

        coin_data = df[df["crypto_name"] == selected_crypto].sort_values("date").reset_index(drop=True)

        if len(coin_data) > 0:
            forecast = predictor.predict_latest_for_coin(selected_crypto)

            # Top KPI metrics
            kpi1, kpi2, kpi3, kpi4 = st.columns(4)
            with kpi1:
                st.metric("Latest Close Price", f"${forecast['close_price']:,.2f}")
            with kpi2:
                st.metric("Predicted 7D Volatility (Ann.)", forecast["predicted_volatility_pct"])
            with kpi3:
                st.metric("Predicted Daily Volatility", forecast["predicted_daily_volatility_pct"])
            with kpi4:
                st.markdown(
                    f"""
                    <div style="background-color: #F8FAFC; border: 1px solid #E2E8F0; border-radius: 8px; padding: 10px;">
                        <span style="font-size: 0.85rem; color: #64748B;">Risk Regime</span><br>
                        <span class="risk-badge" style="background-color: {forecast['risk_color']};">{forecast['risk_level']} Risk</span>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )

            st.caption(f"ℹ️ {forecast['risk_description']} (Observation Date: {forecast['latest_date']})")

            st.divider()

            # Technical Indicators Row
            st.subheader("Current Technical & Liquidity Status")
            tcol1, tcol2, tcol3, tcol4 = st.columns(4)
            tcol1.metric("RSI (14-Day)", f"{forecast['rsi_14']}")
            tcol2.metric("Normalized ATR", f"{forecast['natr_14']}%")
            tcol3.metric("Bollinger Bandwidth", f"{forecast['bb_bandwidth']:.4f}")
            tcol4.metric("Liquidity Ratio (Vol/Cap)", f"{forecast['liquidity_ratio']:.4f}")

            # Charts
            st.subheader(f"Historical Price & Volatility Trends: {selected_crypto}")

            # Plot interactive dual-axis chart
            fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 6), sharex=True, gridspec_kw={"height_ratios": [2, 1]})

            # Price chart
            ax1.plot(coin_data["date"], coin_data["close"], label="Close Price (USD)", color="#1f77b4", linewidth=1.5)
            ax1.set_ylabel("Price ($)", color="#1f77b4")
            ax1.set_title(f"{selected_crypto} Historical Price Action & Realized Volatility", fontsize=13)
            ax1.legend(loc="upper left")

            # Volatility chart
            ax2.plot(
                coin_data["date"],
                coin_data["rolling_vol_7d"] * 100,
                label="Historical 7D Volatility (%)",
                color="#e377c2",
                alpha=0.7,
                linewidth=1.2,
            )
            ax2.plot(
                coin_data["date"],
                coin_data["target_vol_7d"] * 100,
                label="Forward Target Volatility (%)",
                color="#2ca02c",
                alpha=0.8,
                linewidth=1.2,
            )
            ax2.set_ylabel("Volatility (%)")
            ax2.set_xlabel("Date")
            ax2.legend(loc="upper left")

            plt.tight_layout()
            st.pyplot(fig)
            plt.close(fig)

    # ---------------------------------------------------------
    # TAB 2: SCENARIO SIMULATOR
    # ---------------------------------------------------------
    elif menu == "🎛️ Scenario Simulator":
        st.markdown('<div class="main-header">🎛️ Interactive Volatility Simulator</div>', unsafe_allow_html=True)
        st.markdown(
            '<div class="sub-header">Adjust market variables to simulate potential shockwaves and forecast volatility response.</div>',
            unsafe_allow_html=True,
        )

        sim_coin = st.selectbox("Baseline Coin for Scenario Simulation:", available_cryptos, index=0)
        coin_row = df[df["crypto_name"] == sim_coin].sort_values("date").iloc[-1]

        st.info(f"Simulating based on latest market conditions for **{sim_coin}**.")

        col1, col2 = st.columns(2)
        with col1:
            sim_rolling_vol = st.slider(
                "Historical 7D Rolling Volatility",
                min_value=0.1,
                max_value=3.0,
                value=float(coin_row["rolling_vol_7d"]),
                step=0.05,
            )
            sim_natr = st.slider(
                "Normalized ATR (% Daily True Range)",
                min_value=1.0,
                max_value=30.0,
                value=float(coin_row["natr_14"]),
                step=0.5,
            )
            sim_bb_width = st.slider(
                "Bollinger Bandwidth (Band Expansion)",
                min_value=0.05,
                max_value=2.0,
                value=float(coin_row["bb_bandwidth"]),
                step=0.05,
            )
        with col2:
            sim_rsi = st.slider(
                "Relative Strength Index (RSI 14)",
                min_value=10.0,
                max_value=90.0,
                value=float(coin_row["rsi_14"]),
                step=1.0,
            )
            sim_ret_1d = st.slider(
                "1-Day Price Return (%)",
                min_value=-25.0,
                max_value=25.0,
                value=float(coin_row["log_ret_1d"] * 100),
                step=0.5,
            )
            sim_liquidity = st.slider(
                "Liquidity Ratio (Volume / Market Cap)",
                min_value=0.01,
                max_value=1.5,
                value=float(coin_row["liquidity_ratio"]),
                step=0.02,
            )

        # Build feature vector
        feat_vector = coin_row[predictor.feature_columns].copy()
        feat_vector["rolling_vol_7d"] = sim_rolling_vol
        feat_vector["natr_14"] = sim_natr
        feat_vector["bb_bandwidth"] = sim_bb_width
        feat_vector["rsi_14"] = sim_rsi
        feat_vector["log_ret_1d"] = sim_ret_1d / 100.0
        feat_vector["liquidity_ratio"] = sim_liquidity

        pred_vol = predictor.predict_features(feat_vector.values.reshape(1, -1))[0]
        risk = predictor.classify_risk(pred_vol)

        st.divider()
        res_col1, res_col2 = st.columns([1, 2])
        with res_col1:
            st.metric("Simulated Predicted 7D Volatility", f"{pred_vol * 100:.2f}%")
            st.metric("Simulated Daily Volatility", f"{(pred_vol / np.sqrt(365.0)) * 100:.2f}%")
        with res_col2:
            st.markdown(
                f"""
                <div style="background-color: #F8FAFC; border: 2px solid {risk['color']}; border-radius: 10px; padding: 1.5rem;">
                    <h3 style="margin-top:0; color: {risk['color']};">Risk Level: {risk['level']}</h3>
                    <p style="font-size: 1.1rem; color: #334155;">{risk['description']}</p>
                </div>
                """,
                unsafe_allow_html=True,
            )

    # ---------------------------------------------------------
    # TAB 3: MODEL BENCHMARKS & IMPORTANCE
    # ---------------------------------------------------------
    elif menu == "📊 Model Benchmarks & Importance":
        st.markdown('<div class="main-header">📊 Model Performance Benchmarks</div>', unsafe_allow_html=True)
        st.markdown(
            '<div class="sub-header">Evaluation metrics on out-of-time test dataset (2022 market downturn).</div>',
            unsafe_allow_html=True,
        )

        if metrics:
            comp_data = []
            for m_name, m_res in metrics.items():
                comp_data.append(
                    {
                        "Model Architecture": m_name.replace("_", " "),
                        "Val RMSE": m_res["val"]["RMSE"],
                        "Val MAE": m_res["val"]["MAE"],
                        "Val R²": m_res["val"]["R2"],
                        "Test RMSE": m_res["test"]["RMSE"],
                        "Test MAE": m_res["test"]["MAE"],
                        "Test R²": m_res["test"]["R2"],
                        "Test MAPE (%)": m_res["test"]["MAPE"],
                    }
                )
            comp_df = pd.DataFrame(comp_data)
            st.dataframe(comp_df.style.highlight_min(subset=["Test RMSE", "Test MAE"], color="#D1FAE5"), use_container_width=True)

        st.divider()
        st.subheader("Visual Model Diagnostics")
        fig_col1, fig_col2 = st.columns(2)

        comp_fig_path = os.path.join("reports", "figures", "model_comparison.png")
        imp_fig_path = os.path.join("reports", "figures", "feature_importance.png")

        if os.path.exists(comp_fig_path):
            with fig_col1:
                st.image(comp_fig_path, caption="Cross-Model Benchmark Comparison on Test Set")
        if os.path.exists(imp_fig_path):
            with fig_col2:
                st.image(imp_fig_path, caption="Top Feature Importance Rankings")

        st.divider()
        pred_fig_path = os.path.join("reports", "figures", "predicted_vs_actual.png")
        res_fig_path = os.path.join("reports", "figures", "residuals_distribution.png")

        fig_col3, fig_col4 = st.columns(2)
        if os.path.exists(pred_fig_path):
            with fig_col3:
                st.image(pred_fig_path, caption="Actual vs Predicted Volatility Alignment (Bitcoin)")
        if os.path.exists(res_fig_path):
            with fig_col4:
                st.image(res_fig_path, caption="Residual Error Distribution")

    # ---------------------------------------------------------
    # TAB 4: HISTORICAL EDA EXPLORER
    # ---------------------------------------------------------
    elif menu == "📈 Historical EDA Explorer":
        st.markdown('<div class="main-header">📈 Exploratory Data Analysis & Market Dynamics</div>', unsafe_allow_html=True)
        st.markdown(
            '<div class="sub-header">Empirical insights from over 71,000 daily observations across 55 cryptocurrencies.</div>',
            unsafe_allow_html=True,
        )

        eda_p1 = os.path.join("reports", "figures", "eda_price_trends.png")
        eda_p2 = os.path.join("reports", "figures", "eda_volatility_clustering.png")
        eda_p3 = os.path.join("reports", "figures", "eda_correlation_matrix.png")
        eda_p4 = os.path.join("reports", "figures", "eda_volatility_distribution.png")
        eda_p5 = os.path.join("reports", "figures", "eda_volume_vs_marketcap.png")
        eda_p6 = os.path.join("reports", "figures", "eda_crypto_volatility_ranking.png")

        c1, c2 = st.columns(2)
        if os.path.exists(eda_p1):
            c1.image(eda_p1, caption="Historical Price Trends (Log Scale)")
        if os.path.exists(eda_p2):
            c2.image(eda_p2, caption="Returns Volatility Clustering (ARCH Effect)")

        st.divider()
        c3, c4 = st.columns(2)
        if os.path.exists(eda_p3):
            c3.image(eda_p3, caption="Feature Correlation Heatmap")
        if os.path.exists(eda_p4):
            c4.image(eda_p4, caption="Volatility & Return Distributions (Fat Tails)")

        st.divider()
        c5, c6 = st.columns(2)
        if os.path.exists(eda_p5):
            c5.image(eda_p5, caption="Liquidity: Volume vs Market Cap")
        if os.path.exists(eda_p6):
            c6.image(eda_p6, caption="Asset Volatility Rankings")


if __name__ == "__main__":
    main()
