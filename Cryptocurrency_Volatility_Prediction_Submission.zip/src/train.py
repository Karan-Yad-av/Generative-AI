"""
Model Training and Hyperparameter Tuning Pipeline.
Implements temporal train-val-test splitting, data scaling, multi-model training,
and artifact serialization.
"""

import os
import json
import logging
import joblib
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler

from src.feature_engineering import FEATURE_COLUMNS, TARGET_COLUMN
from src.models import get_models
from src.evaluate import (
    calculate_metrics,
    plot_model_comparison,
    plot_feature_importance,
    plot_predictions_vs_actual,
    plot_residuals,
)

logger = logging.getLogger(__name__)

MODELS_DIR = "models"
REPORTS_DIR = os.path.join("reports", "figures")
os.makedirs(MODELS_DIR, exist_ok=True)
os.makedirs(REPORTS_DIR, exist_ok=True)


def train_pipeline(data_path: str = "data/processed/crypto_features.csv"):
    """
    Executes the full model training and evaluation lifecycle.
    """
    if not os.path.exists(data_path):
        from src.data_loader import load_raw_data
        from src.preprocessing import clean_and_preprocess
        from src.feature_engineering import create_feature_pipeline

        logger.info("Processed data not found at %s. Running feature pipeline...", data_path)
        raw_df = load_raw_data()
        clean_df = clean_and_preprocess(raw_df)
        df = create_feature_pipeline(clean_df)
    else:
        logger.info("Loading processed dataset from %s", data_path)
        df = pd.read_csv(data_path)
        df["date"] = pd.to_datetime(df["date"])

    df = df.sort_values("date").reset_index(drop=True)

    # 1. Temporal split to avoid data leakage
    # Train: 2013 through 2020 (Historical baseline & initial bull cycles)
    # Val: 2021 (All-time high bull/correction regime)
    # Test: 2022 (Unseen modern test period)
    train_mask = df["date"] < "2021-01-01"
    val_mask = (df["date"] >= "2021-01-01") & (df["date"] < "2022-01-01")
    test_mask = df["date"] >= "2022-01-01"

    train_df = df[train_mask]
    val_df = df[val_mask]
    test_df = df[test_mask]

    logger.info(
        "Data split summary:\n- Train: %d rows (%s to %s)\n- Val:   %d rows (%s to %s)\n- Test:  %d rows (%s to %s)",
        len(train_df),
        train_df["date"].min().date(),
        train_df["date"].max().date(),
        len(val_df),
        val_df["date"].min().date(),
        val_df["date"].max().date(),
        len(test_df),
        test_df["date"].min().date(),
        test_df["date"].max().date(),
    )

    X_train = train_df[FEATURE_COLUMNS].values
    y_train = train_df[TARGET_COLUMN].values

    X_val = val_df[FEATURE_COLUMNS].values
    y_val = val_df[TARGET_COLUMN].values

    X_test = test_df[FEATURE_COLUMNS].values
    y_test = test_df[TARGET_COLUMN].values

    # 2. Scaler fitted ONLY on train set
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_val_scaled = scaler.transform(X_val)
    X_test_scaled = scaler.transform(X_test)

    # Save scaler immediately
    scaler_path = os.path.join(MODELS_DIR, "scaler.pkl")
    joblib.dump(scaler, scaler_path)
    logger.info("StandardScaler saved to %s", scaler_path)

    # 3. Model training and evaluation
    models = get_models()
    results = {}
    best_model_name = None
    best_val_rmse = float("inf")
    trained_model_objects = {}

    for name, model in models.items():
        logger.info("Training %s...", name)

        # Baseline doesn't use scaling; Ridge uses scaled; Trees work with raw or scaled
        if name == "Ridge_Regression":
            model.fit(X_train_scaled, y_train)
            train_preds = model.predict(X_train_scaled)
            val_preds = model.predict(X_val_scaled)
            test_preds = model.predict(X_test_scaled)
        elif name == "Baseline_Persistence":
            model.fit(X_train, y_train)
            train_preds = model.predict(X_train)
            val_preds = model.predict(X_val)
            test_preds = model.predict(X_test)
        else:
            # Tree models fit on scaled or unscaled features (using unscaled for interpretability)
            model.fit(X_train, y_train)
            train_preds = model.predict(X_train)
            val_preds = model.predict(X_val)
            test_preds = model.predict(X_test)

        trained_model_objects[name] = model

        train_metrics = calculate_metrics(y_train, train_preds)
        val_metrics = calculate_metrics(y_val, val_preds)
        test_metrics = calculate_metrics(y_test, test_preds)

        results[name] = {
            "train": train_metrics,
            "val": val_metrics,
            "test": test_metrics,
        }

        logger.info(
            "%s Results -> Val RMSE: %.4f | Val R2: %.4f | Test RMSE: %.4f | Test R2: %.4f",
            name,
            val_metrics["RMSE"],
            val_metrics["R2"],
            test_metrics["RMSE"],
            test_metrics["R2"],
        )

        if name != "Baseline_Persistence" and val_metrics["RMSE"] < best_val_rmse:
            best_val_rmse = val_metrics["RMSE"]
            best_model_name = name

    logger.info("Best model selected: %s (Val RMSE: %.4f)", best_model_name, best_val_rmse)

    # 4. Save best model and artifacts
    best_model = trained_model_objects[best_model_name]
    best_model_path = os.path.join(MODELS_DIR, "best_volatility_model.pkl")
    joblib.dump(best_model, best_model_path)
    logger.info("Saved best model to %s", best_model_path)

    # Save feature metadata
    metadata = {
        "best_model_name": best_model_name,
        "feature_columns": FEATURE_COLUMNS,
        "target_column": TARGET_COLUMN,
        "num_features": len(FEATURE_COLUMNS),
        "split_dates": {
            "train_end": "2020-12-31",
            "val_end": "2021-12-31",
            "test_end": "2022-10-23",
        },
    }
    with open(os.path.join(MODELS_DIR, "feature_metadata.json"), "w") as f:
        json.dump(metadata, f, indent=4)

    # Save metrics JSON
    with open(os.path.join(MODELS_DIR, "model_metrics.json"), "w") as f:
        json.dump(results, f, indent=4)

    # 5. Generate Evaluation Figures
    plot_model_comparison(results, os.path.join(REPORTS_DIR, "model_comparison.png"))

    if hasattr(best_model, "feature_importances_"):
        plot_feature_importance(best_model, FEATURE_COLUMNS, os.path.join(REPORTS_DIR, "feature_importance.png"))

    # Generate predictions for Bitcoin on test set for visualization
    btc_test_mask = test_df["crypto_name"] == "Bitcoin"
    btc_test = test_df[btc_test_mask]
    if len(btc_test) > 0:
        if best_model_name == "Ridge_Regression":
            btc_preds = best_model.predict(scaler.transform(btc_test[FEATURE_COLUMNS].values))
        else:
            btc_preds = best_model.predict(btc_test[FEATURE_COLUMNS].values)

        plot_predictions_vs_actual(
            btc_test[TARGET_COLUMN].values,
            btc_preds,
            btc_test["date"],
            "Bitcoin",
            os.path.join(REPORTS_DIR, "predicted_vs_actual.png"),
        )
        plot_residuals(
            btc_test[TARGET_COLUMN].values,
            btc_preds,
            os.path.join(REPORTS_DIR, "residuals_distribution.png"),
        )

    logger.info("Training pipeline complete! All artifacts and evaluation plots generated.")
    return results, best_model_name


if __name__ == "__main__":
    results, best = train_pipeline()
    print("\nFinal Results Summary:\n", json.dumps(results, indent=2))
