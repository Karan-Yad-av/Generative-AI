"""
Cryptocurrency Volatility Prediction Package
Author: Machine Learning & Quantitative Research Team
"""

__version__ = "1.0.0"
