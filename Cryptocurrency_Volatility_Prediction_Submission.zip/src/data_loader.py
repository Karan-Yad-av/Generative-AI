"""
Data Loader Module for Cryptocurrency Historical Prices Dataset.
Handles loading, schema normalization, and basic data integrity validation.
"""

import os
import zipfile
import logging
import pandas as pd
from typing import Optional

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

REQUIRED_COLUMNS = ["open", "high", "low", "close", "volume", "marketcap", "crypto_name", "date"]


def load_raw_data(file_path: Optional[str] = None) -> pd.DataFrame:
    """
    Loads cryptocurrency historical dataset from CSV or ZIP.

    Parameters:
    -----------
    file_path : Optional[str]
        Path to dataset.csv or dataset.csv.zip. Defaults to data/raw/dataset.csv.

    Returns:
    --------
    pd.DataFrame:
        Loaded raw DataFrame with standardized column names and date parsed.
    """
    if file_path is None:
        file_path = os.path.join("data", "raw", "dataset.csv")

    if not os.path.exists(file_path):
        zip_path = os.path.join("data", "raw", "dataset.csv.zip")
        if os.path.exists(zip_path):
            logger.info("Extracting %s...", zip_path)
            with zipfile.ZipFile(zip_path, "r") as z:
                z.extractall(os.path.join("data", "raw"))
        else:
            raise FileNotFoundError(f"Dataset not found at {file_path} or {zip_path}")

    logger.info("Loading dataset from: %s", file_path)
    df = pd.read_csv(file_path)

    # Standardize column naming
    rename_dict = {}
    for col in df.columns:
        norm_col = col.strip().lower()
        if norm_col in ["marketcap", "market_cap"]:
            rename_dict[col] = "market_cap"
        elif norm_col in ["crypto_name", "cryptoname", "coin_name", "name"]:
            rename_dict[col] = "crypto_name"
        elif norm_col in ["symbol"]:
            rename_dict[col] = "symbol"
        else:
            rename_dict[col] = norm_col

    df = df.rename(columns=rename_dict)

    # Drop index artifact columns if present
    drop_candidates = ["unnamed: 0", "index"]
    for c in drop_candidates:
        if c in df.columns:
            df = df.drop(columns=[c])

    # Parse dates and sort
    if "date" in df.columns:
        df["date"] = pd.to_datetime(df["date"], errors="coerce")
    elif "timestamp" in df.columns:
        df["date"] = pd.to_datetime(df["timestamp"], errors="coerce")
    else:
        raise ValueError("Dataset does not contain a recognized 'date' or 'timestamp' column.")

    # Validate required columns
    expected = ["open", "high", "low", "close", "volume", "market_cap", "crypto_name", "date"]
    missing = [c for c in expected if c not in df.columns]
    if missing:
        raise ValueError(f"Missing expected columns: {missing}")

    # Ensure numeric columns are float
    numeric_cols = ["open", "high", "low", "close", "volume", "market_cap"]
    for col in numeric_cols:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    # Sort deterministically
    df = df.sort_values(by=["crypto_name", "date"]).reset_index(drop=True)

    logger.info(
        "Successfully loaded %d rows across %d unique cryptocurrencies. Date range: %s to %s",
        len(df),
        df["crypto_name"].nunique(),
        df["date"].min().strftime("%Y-%m-%d"),
        df["date"].max().strftime("%Y-%m-%d"),
    )

    return df


if __name__ == "__main__":
    df = load_raw_data()
    print("Shape:", df.shape)
    print("Columns:", df.columns.tolist())
    print("Head:\n", df.head(3))
