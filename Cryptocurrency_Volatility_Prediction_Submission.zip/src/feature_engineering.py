"""
Feature Engineering Module for Cryptocurrency Volatility Forecasting.
Computes technical indicators, liquidity ratios, multi-scale rolling volatilities,
and the forward realized volatility target variable.
"""

import logging
import numpy as np
import pandas as pd
from typing import List, Tuple

logger = logging.getLogger(__name__)

FEATURE_COLUMNS = [
    # Historical rolling volatility
    "rolling_vol_7d",
    "rolling_vol_14d",
    "rolling_vol_30d",
    "parkinson_vol_7d",
    "garman_klass_vol_7d",
    "vol_ratio_7_30",
    # Returns
    "log_ret_1d",
    "log_ret_3d",
    "log_ret_7d",
    "log_ret_14d",
    "log_ret_30d",
    # Moving averages & trend
    "close_to_sma_7",
    "close_to_sma_14",
    "close_to_sma_30",
    "sma_7_to_sma_30",
    # Bollinger Bands
    "bb_bandwidth",
    "bb_percent_b",
    # Range & Volatility indicators
    "natr_14",
    "rsi_14",
    "macd_norm",
    "macd_hist_norm",
    # Liquidity & Volume
    "liquidity_ratio",
    "volume_to_sma_7",
    "log_volume",
    "log_market_cap",
    # Calendar
    "day_of_week",
    "is_weekend",
    "month",
]

TARGET_COLUMN = "target_vol_7d"


def compute_rsi(series: pd.Series, period: int = 14) -> pd.Series:
    """Computes standard Relative Strength Index (RSI)."""
    delta = series.diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)

    # Exponential moving average for RSI smoothing
    avg_gain = gain.ewm(alpha=1 / period, min_periods=period, adjust=False).mean()
    avg_loss = loss.ewm(alpha=1 / period, min_periods=period, adjust=False).mean()

    rs = avg_gain / (avg_loss + 1e-9)
    rsi = 100 - (100 / (1 + rs))
    return rsi


def compute_atr(df_group: pd.DataFrame, period: int = 14) -> Tuple[pd.Series, pd.Series]:
    """Computes Average True Range (ATR) and Normalized ATR (% of Close)."""
    prev_close = df_group["close"].shift(1)
    tr1 = df_group["high"] - df_group["low"]
    tr2 = (df_group["high"] - prev_close).abs()
    tr3 = (df_group["low"] - prev_close).abs()
    true_range = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)

    atr = true_range.ewm(alpha=1 / period, min_periods=period, adjust=False).mean()
    natr = (atr / (df_group["close"] + 1e-9)) * 100.0
    return atr, natr


def engineer_crypto_features(group: pd.DataFrame, fwd_horizon: int = 7) -> pd.DataFrame:
    """
    Computes all features and the forward volatility target for a single cryptocurrency series.
    """
    g = group.copy().sort_values("date").reset_index(drop=True)

    # 1. Log returns
    log_close = np.log(g["close"])
    g["log_ret_1d"] = log_close.diff(1)
    g["log_ret_3d"] = log_close.diff(3)
    g["log_ret_7d"] = log_close.diff(7)
    g["log_ret_14d"] = log_close.diff(14)
    g["log_ret_30d"] = log_close.diff(30)

    # 2. Historical Rolling Volatility (annualized with sqrt(365))
    sqrt_365 = np.sqrt(365.0)
    g["rolling_vol_7d"] = g["log_ret_1d"].rolling(7, min_periods=5).std() * sqrt_365
    g["rolling_vol_14d"] = g["log_ret_1d"].rolling(14, min_periods=10).std() * sqrt_365
    g["rolling_vol_30d"] = g["log_ret_1d"].rolling(30, min_periods=20).std() * sqrt_365

    # Volatility term structure ratio (short vs long)
    g["vol_ratio_7_30"] = g["rolling_vol_7d"] / (g["rolling_vol_30d"] + 1e-6)

    # 3. Extreme Price Range Volatility Estimators
    # Parkinson Volatility: uses High and Low
    hl_ratio_sq = (np.log(g["high"] / (g["low"] + 1e-9))) ** 2
    parkinson_const = 1.0 / (4.0 * np.log(2.0))
    g["parkinson_vol_7d"] = np.sqrt(hl_ratio_sq.rolling(7, min_periods=5).mean() * parkinson_const * 365.0)

    # Garman-Klass Volatility: uses Open, High, Low, Close
    co_ratio_sq = (np.log(g["close"] / (g["open"] + 1e-9))) ** 2
    gk_daily = 0.5 * hl_ratio_sq - (2.0 * np.log(2.0) - 1.0) * co_ratio_sq
    gk_daily = gk_daily.clip(lower=0)
    g["garman_klass_vol_7d"] = np.sqrt(gk_daily.rolling(7, min_periods=5).mean() * 365.0)

    # 4. Moving Averages and Trends
    sma_7 = g["close"].rolling(7, min_periods=5).mean()
    sma_14 = g["close"].rolling(14, min_periods=10).mean()
    sma_30 = g["close"].rolling(30, min_periods=20).mean()
    ema_12 = g["close"].ewm(span=12, adjust=False).mean()
    ema_26 = g["close"].ewm(span=26, adjust=False).mean()

    g["close_to_sma_7"] = (g["close"] / (sma_7 + 1e-9)) - 1.0
    g["close_to_sma_14"] = (g["close"] / (sma_14 + 1e-9)) - 1.0
    g["close_to_sma_30"] = (g["close"] / (sma_30 + 1e-9)) - 1.0
    g["sma_7_to_sma_30"] = (sma_7 / (sma_30 + 1e-9)) - 1.0

    # 5. Bollinger Bands (20-day window)
    bb_window = 20
    bb_mid = g["close"].rolling(bb_window, min_periods=15).mean()
    bb_std = g["close"].rolling(bb_window, min_periods=15).std()
    bb_upper = bb_mid + (2.0 * bb_std)
    bb_lower = bb_mid - (2.0 * bb_std)

    g["bb_bandwidth"] = (bb_upper - bb_lower) / (bb_mid + 1e-9)
    g["bb_percent_b"] = (g["close"] - bb_lower) / (bb_upper - bb_lower + 1e-9)

    # 6. ATR & Normalized ATR
    _, atr_raw = compute_atr(g, period=14)
    g["natr_14"] = atr_raw.clip(0, 100.0)

    # 7. RSI
    g["rsi_14"] = compute_rsi(g["close"], period=14)

    # 8. MACD
    macd = ema_12 - ema_26
    macd_signal = macd.ewm(span=9, adjust=False).mean()
    macd_hist = macd - macd_signal

    g["macd_norm"] = (macd / (g["close"] + 1e-9)).clip(-2.0, 2.0)
    g["macd_hist_norm"] = (macd_hist / (g["close"] + 1e-9)).clip(-2.0, 2.0)

    # 9. Liquidity & Volume Ratios
    g["liquidity_ratio"] = g["volume"] / (g["market_cap"] + 1e-6)
    vol_sma_7 = g["volume"].rolling(7, min_periods=5).mean()
    g["volume_to_sma_7"] = g["volume"] / (vol_sma_7 + 1e-6)
    g["log_volume"] = np.log1p(g["volume"])
    g["log_market_cap"] = np.log1p(g["market_cap"])

    # 10. Calendar Features
    g["day_of_week"] = g["date"].dt.dayofweek
    g["is_weekend"] = g["day_of_week"].isin([5, 6]).astype(int)
    g["month"] = g["date"].dt.month

    # 11. Target Variable: Forward 7-day Realized Volatility
    # Shifts 1 step forward so today's return is NOT inside the forward window
    # Window of next 7 future log returns: r_{t+1} to r_{t+7}
    fwd_ret = g["log_ret_1d"].shift(-1)
    indexer = pd.api.indexers.FixedForwardWindowIndexer(window_size=fwd_horizon)
    g[TARGET_COLUMN] = fwd_ret.rolling(window=indexer, min_periods=5).std() * sqrt_365

    return g


def create_feature_pipeline(df: pd.DataFrame, clip_outliers: bool = True) -> pd.DataFrame:
    """
    Applies feature engineering across all cryptocurrencies and filters NaN rows.

    Parameters:
    -----------
    df : pd.DataFrame
        Cleaned cryptocurrency DataFrame.
    clip_outliers : bool
        Whether to cap extreme target volatility outliers at 99.5th percentile for training stability.

    Returns:
    --------
    pd.DataFrame:
        Fully engineered dataset with features and target variable.
    """
    logger.info("Generating features for %d cryptocurrencies...", df["crypto_name"].nunique())

    processed_groups = []
    for crypto_name, group in df.groupby("crypto_name"):
        processed_g = engineer_crypto_features(group)
        processed_groups.append(processed_g)

    feat_df = pd.concat(processed_groups, ignore_index=True)

    # Drop warm-up rows (first 30 days have rolling NaN) and last 7 days (target forward window NaN)
    initial_len = len(feat_df)
    feat_df = feat_df.dropna(subset=FEATURE_COLUMNS + [TARGET_COLUMN]).copy()
    logger.info("Dropped initial/trailing window rows with NaNs: %d -> %d", initial_len, len(feat_df))

    if clip_outliers:
        cap_val = feat_df[TARGET_COLUMN].quantile(0.995)
        logger.info("Clipping target volatility outliers above 99.5th percentile (%.3f)", cap_val)
        feat_df[TARGET_COLUMN] = feat_df[TARGET_COLUMN].clip(upper=cap_val)

    # Ensure no infinite values
    for col in FEATURE_COLUMNS:
        feat_df[col] = feat_df[col].replace([np.inf, -np.inf], np.nan)
        col_median = feat_df[col].median()
        feat_df[col] = feat_df[col].fillna(col_median)

    logger.info("Feature engineering complete. Final dataset shape: %s", feat_df.shape)
    return feat_df


if __name__ == "__main__":
    from src.data_loader import load_raw_data
    from src.preprocessing import clean_and_preprocess

    raw_df = load_raw_data()
    clean_df = clean_and_preprocess(raw_df)
    features_df = create_feature_pipeline(clean_df)
    print("Features summary:")
    print(features_df[FEATURE_COLUMNS].describe().T[["mean", "std", "min", "max"]])
    print("\nTarget summary:")
    print(features_df[TARGET_COLUMN].describe())
