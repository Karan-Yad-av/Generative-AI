"""
Model Architecture and Definitions for Cryptocurrency Volatility Forecasting.
Includes Naive Historical Persistence Baseline, Regularized Linear Model, Random Forest, and XGBoost.
"""

from typing import Dict, Any, Optional
import numpy as np
from sklearn.base import BaseEstimator, RegressorMixin
from sklearn.linear_model import Ridge
from sklearn.ensemble import RandomForestRegressor
import xgboost as xgb


class PersistenceBaselineRegressor(BaseEstimator, RegressorMixin):
    """
    Baseline benchmark: Predicts the recent 7-day rolling historical volatility
    as the future 7-day forward volatility (Random Walk / Martingale hypothesis).
    """

    def __init__(self, rolling_col_idx: int = 0):
        self.rolling_col_idx = rolling_col_idx

    def fit(self, X, y=None):
        return self

    def predict(self, X):
        if hasattr(X, "iloc"):
            return X.iloc[:, self.rolling_col_idx].values
        return X[:, self.rolling_col_idx]


def get_models(random_state: int = 42) -> Dict[str, Any]:
    """
    Returns a dictionary of models to be trained and evaluated.
    """
    models = {
        "Baseline_Persistence": PersistenceBaselineRegressor(rolling_col_idx=0),
        "Ridge_Regression": Ridge(alpha=100.0, random_state=random_state),
        "Random_Forest": RandomForestRegressor(
            n_estimators=100,
            max_depth=12,
            min_samples_split=20,
            min_samples_leaf=10,
            n_jobs=-1,
            random_state=random_state,
        ),
        "XGBoost": xgb.XGBRegressor(
            n_estimators=250,
            learning_rate=0.05,
            max_depth=6,
            subsample=0.8,
            colsample_bytree=0.8,
            reg_alpha=0.1,
            reg_lambda=1.0,
            n_jobs=-1,
            random_state=random_state,
        ),
    }
    return models
