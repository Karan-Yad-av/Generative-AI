"""
EDA and Visualization Generator for Cryptocurrency Volatility Project.
Produces professional, publication-quality figures for the EDA Report.
"""

import os
import json
import logging
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from src.data_loader import load_raw_data
from src.preprocessing import clean_and_preprocess
from src.feature_engineering import create_feature_pipeline, FEATURE_COLUMNS, TARGET_COLUMN

logger = logging.getLogger(__name__)

# Set style
plt.style.use("seaborn-v0_8-whitegrid" if "seaborn-v0_8-whitegrid" in plt.style.available else "default")
plt.rcParams["font.family"] = "sans-serif"
plt.rcParams["font.size"] = 11
plt.rcParams["axes.titlesize"] = 14
plt.rcParams["axes.labelsize"] = 12
plt.rcParams["figure.titlesize"] = 16

FIGURES_DIR = os.path.join("reports", "figures")
os.makedirs(FIGURES_DIR, exist_ok=True)


def generate_all_eda_plots() -> dict:
    """Generates all exploratory plots and returns dataset statistical metrics."""
    logger.info("Generating EDA figures...")
    raw_df = load_raw_data()
    clean_df = clean_and_preprocess(raw_df)
    feat_df = create_feature_pipeline(clean_df)

    stats = {
        "raw_rows": int(len(raw_df)),
        "processed_rows": int(len(feat_df)),
        "num_cryptos": int(clean_df["crypto_name"].nunique()),
        "min_date": str(clean_df["date"].min().date()),
        "max_date": str(clean_df["date"].max().date()),
        "mean_volatility": float(feat_df[TARGET_COLUMN].mean()),
        "median_volatility": float(feat_df[TARGET_COLUMN].median()),
        "std_volatility": float(feat_df[TARGET_COLUMN].std()),
    }

    # 1. Price Trends of Major Cryptocurrencies (Normalized to 100)
    fig, ax = plt.subplots(figsize=(12, 6))
    major_coins = ["Bitcoin", "Ethereum", "Litecoin", "XRP", "Cardano", "Dogecoin"]
    palette = sns.color_palette("tab10", len(major_coins))

    for coin, color in zip(major_coins, palette):
        coin_sub = clean_df[clean_df["crypto_name"] == coin].sort_values("date")
        if len(coin_sub) > 100:
            norm_price = (coin_sub["close"] / coin_sub["close"].iloc[0]) * 100.0
            ax.plot(coin_sub["date"], norm_price, label=coin, color=color, linewidth=2.0)

    ax.set_yscale("log")
    ax.set_title("Historical Normalized Price Trends of Major Cryptocurrencies (Log Scale, Base=100)")
    ax.set_xlabel("Year")
    ax.set_ylabel("Normalized Price (Log Scale)")
    ax.legend(frameon=True, loc="upper left")
    plt.tight_layout()
    fig.savefig(os.path.join(FIGURES_DIR, "eda_price_trends.png"), dpi=200)
    plt.close(fig)

    # 2. Volatility Clustering: Bitcoin Daily Returns & Realized Volatility
    btc_sub = feat_df[feat_df["crypto_name"] == "Bitcoin"].sort_values("date")
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(13, 8), sharex=True)

    ax1.plot(btc_sub["date"], btc_sub["log_ret_1d"] * 100, color="#1f77b4", alpha=0.7, linewidth=0.8)
    ax1.axhline(0, color="black", linestyle="--", alpha=0.5, linewidth=1)
    ax1.set_ylabel("Daily Return (%)")
    ax1.set_title("Bitcoin Daily Log Returns (Notice Volatility Clustering)", fontsize=13)

    ax2.plot(btc_sub["date"], btc_sub["rolling_vol_7d"] * 100, color="#d62728", label="7-Day Rolling Volatility", linewidth=1.2)
    ax2.plot(btc_sub["date"], btc_sub["parkinson_vol_7d"] * 100, color="#ff7f0e", alpha=0.7, label="Parkinson Volatility", linewidth=1.0)
    ax2.set_ylabel("Annualized Volatility (%)")
    ax2.set_xlabel("Year")
    ax2.legend(frameon=True)
    ax2.set_title("Bitcoin Rolling & Parkinson Volatility (ARCH Phenomenon)", fontsize=13)

    plt.tight_layout()
    fig.savefig(os.path.join(FIGURES_DIR, "eda_volatility_clustering.png"), dpi=200)
    plt.close(fig)

    # 3. Correlation Heatmap of Key Predictive Features vs Target
    key_features = [
        "rolling_vol_7d",
        "rolling_vol_14d",
        "rolling_vol_30d",
        "parkinson_vol_7d",
        "garman_klass_vol_7d",
        "vol_ratio_7_30",
        "bb_bandwidth",
        "natr_14",
        "liquidity_ratio",
        "volume_to_sma_7",
        "log_volume",
        "log_market_cap",
        TARGET_COLUMN,
    ]
    corr = feat_df[key_features].corr()
    fig, ax = plt.subplots(figsize=(11, 9))
    mask = np.triu(np.ones_like(corr, dtype=bool))
    sns.heatmap(
        corr,
        mask=mask,
        cmap="coolwarm",
        annot=True,
        fmt=".2f",
        square=True,
        linewidths=0.5,
        cbar_kws={"shrink": 0.8},
        ax=ax,
    )
    ax.set_title("Correlation Matrix of Predictive Technical Indicators & Target Volatility", fontsize=14, pad=12)
    plt.tight_layout()
    fig.savefig(os.path.join(FIGURES_DIR, "eda_correlation_matrix.png"), dpi=200)
    plt.close(fig)

    # 4. Target Volatility & Return Distributions (Fat Tails and Kurtosis)
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))

    sns.histplot(feat_df[TARGET_COLUMN], bins=60, kde=True, color="#2ca02c", ax=ax1)
    ax1.set_title("Distribution of Forward 7-Day Realized Volatility", fontsize=13)
    ax1.set_xlabel("Annualized Volatility (Ratio)")
    ax1.axvline(feat_df[TARGET_COLUMN].mean(), color="red", linestyle="--", label=f"Mean: {feat_df[TARGET_COLUMN].mean():.2f}")
    ax1.axvline(feat_df[TARGET_COLUMN].median(), color="blue", linestyle=":", label=f"Median: {feat_df[TARGET_COLUMN].median():.2f}")
    ax1.legend()

    # Fat-tail log returns
    sns.histplot(feat_df["log_ret_1d"], bins=80, kde=True, color="#9467bd", ax=ax2)
    ax2.set_xlim(-0.35, 0.35)
    ax2.set_title("Daily Log Returns Distribution (Fat Tails / Leptokurtic)", fontsize=13)
    ax2.set_xlabel("Daily Log Return")

    plt.tight_layout()
    fig.savefig(os.path.join(FIGURES_DIR, "eda_volatility_distribution.png"), dpi=200)
    plt.close(fig)

    # 5. Liquidity Relationship: Trading Volume vs Market Capitalization
    fig, ax = plt.subplots(figsize=(10, 6))
    sample_sub = feat_df.sample(min(15000, len(feat_df)), random_state=42)
    scatter = ax.scatter(
        sample_sub["log_market_cap"],
        sample_sub["log_volume"],
        c=sample_sub[TARGET_COLUMN],
        cmap="viridis",
        alpha=0.4,
        s=12,
    )
    cbar = plt.colorbar(scatter, ax=ax)
    cbar.set_label("Forward Volatility", rotation=270, labelpad=15)
    ax.set_title("Market Capitalization vs Trading Volume (Color: Forward Volatility)", fontsize=14)
    ax.set_xlabel("Log(Market Capitalization)")
    ax.set_ylabel("Log(Volume)")
    plt.tight_layout()
    fig.savefig(os.path.join(FIGURES_DIR, "eda_volume_vs_marketcap.png"), dpi=200)
    plt.close(fig)

    # 6. Cryptocurrency Volatility Ranking (Top 10 Most Volatile vs Top 10 Most Stable)
    coin_vol = feat_df.groupby("crypto_name")[TARGET_COLUMN].mean().sort_values()
    top_stable = coin_vol.head(8)
    top_volatile = coin_vol.tail(8)
    combined = pd.concat([top_stable, top_volatile])

    fig, ax = plt.subplots(figsize=(11, 7))
    colors = ["#2ca02c"] * len(top_stable) + ["#d62728"] * len(top_volatile)
    bars = ax.barh(combined.index, combined.values, color=colors, alpha=0.85)
    ax.set_title("Cryptocurrency Volatility Comparison (Annualized Average Volatility)", fontsize=14)
    ax.set_xlabel("Average 7-Day Realized Volatility")
    ax.axvline(feat_df[TARGET_COLUMN].mean(), color="black", linestyle="--", label=f"Market Average: {feat_df[TARGET_COLUMN].mean():.2f}")
    ax.legend(loc="lower right")

    for bar in bars:
        width = bar.get_width()
        ax.text(width + 0.02, bar.get_y() + bar.get_height() / 2, f"{width:.2f}", va="center", fontsize=9)

    plt.tight_layout()
    fig.savefig(os.path.join(FIGURES_DIR, "eda_crypto_volatility_ranking.png"), dpi=200)
    plt.close(fig)

    logger.info("All EDA figures saved to %s", FIGURES_DIR)

    # Also save processed features dataframe to data/processed
    processed_path = os.path.join("data", "processed", "crypto_features.csv")
    feat_df.to_csv(processed_path, index=False)
    logger.info("Saved processed features to %s (%d rows)", processed_path, len(feat_df))

    return stats


if __name__ == "__main__":
    stats = generate_all_eda_plots()
    print("EDA Plot generation complete. Summary stats:", stats)
