"""
Inference Engine for Cryptocurrency Volatility Forecasting.
Provides high-performance inference for live data, custom scenarios, and historical series.
"""

import os
import json
import logging
import joblib
import numpy as np
import pandas as pd
from typing import Dict, Any, Union, Optional

logger = logging.getLogger(__name__)

MODELS_DIR = "models"


class VolatilityPredictor:
    """
    Production Predictor class for Cryptocurrency Volatility Forecasting.
    """

    def __init__(
        self,
        model_path: str = os.path.join(MODELS_DIR, "best_volatility_model.pkl"),
        scaler_path: str = os.path.join(MODELS_DIR, "scaler.pkl"),
        metadata_path: str = os.path.join(MODELS_DIR, "feature_metadata.json"),
    ):
        if not os.path.exists(model_path):
            raise FileNotFoundError(f"Model file not found at {model_path}. Train model first.")

        self.model = joblib.load(model_path)
        self.scaler = joblib.load(scaler_path) if os.path.exists(scaler_path) else None

        with open(metadata_path, "r") as f:
            self.metadata = json.load(f)

        self.feature_columns = self.metadata["feature_columns"]
        self.best_model_name = self.metadata.get("best_model_name", "Model")
        logger.info("Loaded predictor with model %s (%d features)", self.best_model_name, len(self.feature_columns))

    def classify_risk(self, annualized_vol: float) -> Dict[str, str]:
        """Classifies annualized volatility into operational risk categories."""
        if annualized_vol < 0.50:
            return {"level": "Low", "color": "#28a745", "description": "Relatively stable, standard trading bands"}
        elif annualized_vol < 0.85:
            return {"level": "Moderate", "color": "#ffc107", "description": "Typical cryptocurrency market volatility"}
        elif annualized_vol < 1.30:
            return {"level": "High", "color": "#fd7e14", "description": "Elevated risk regime; wider stop-losses advised"}
        else:
            return {"level": "Extreme", "color": "#dc3545", "description": "Extreme turbulence; high liquidation risk"}

    def predict_features(self, X: Union[pd.DataFrame, np.ndarray]) -> np.ndarray:
        """Runs predictions on a DataFrame or numpy array of features."""
        if isinstance(X, pd.DataFrame):
            X_mat = X[self.feature_columns].values
        else:
            X_mat = X

        if self.best_model_name == "Ridge_Regression" and self.scaler is not None:
            X_mat = self.scaler.transform(X_mat)

        preds = self.model.predict(X_mat)
        return np.clip(preds, 0.01, None)

    def predict_latest_for_coin(
        self,
        crypto_name: str,
        data_path: str = os.path.join("data", "processed", "crypto_features.csv"),
    ) -> Dict[str, Any]:
        """
        Retrieves the latest available feature vector for a coin and forecasts forward 7-day volatility.
        """
        if not os.path.exists(data_path):
            raise FileNotFoundError(f"Processed dataset not found at {data_path}.")

        df = pd.read_csv(data_path)
        df["date"] = pd.to_datetime(df["date"])

        coin_data = df[df["crypto_name"].str.lower() == crypto_name.lower()].sort_values("date")
        if len(coin_data) == 0:
            raise ValueError(f"No records found for cryptocurrency '{crypto_name}'.")

        latest_row = coin_data.iloc[-1]
        X_latest = latest_row[self.feature_columns].values.reshape(1, -1)

        pred_annualized = float(self.predict_features(X_latest)[0])
        pred_daily = pred_annualized / np.sqrt(365.0)

        risk_info = self.classify_risk(pred_annualized)

        return {
            "crypto_name": str(latest_row["crypto_name"]),
            "latest_date": str(latest_row["date"].date()),
            "close_price": float(latest_row["close"]),
            "predicted_volatility_annualized": round(pred_annualized, 4),
            "predicted_volatility_pct": f"{pred_annualized * 100:.2f}%",
            "predicted_daily_volatility_pct": f"{pred_daily * 100:.2f}%",
            "historical_7d_volatility_pct": f"{float(latest_row['rolling_vol_7d']) * 100:.2f}%",
            "rsi_14": round(float(latest_row["rsi_14"]), 2),
            "natr_14": round(float(latest_row["natr_14"]), 2),
            "bb_bandwidth": round(float(latest_row["bb_bandwidth"]), 4),
            "liquidity_ratio": round(float(latest_row["liquidity_ratio"]), 4),
            "risk_level": risk_info["level"],
            "risk_color": risk_info["color"],
            "risk_description": risk_info["description"],
        }


if __name__ == "__main__":
    predictor = VolatilityPredictor()
    result = predictor.predict_latest_for_coin("Bitcoin")
    print("\nBitcoin Volatility Forecast:")
    print(json.dumps(result, indent=2))
