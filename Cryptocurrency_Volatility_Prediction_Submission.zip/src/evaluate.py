"""
Evaluation and Metrics Reporting Module for Cryptocurrency Volatility Models.
Calculates RMSE, MAE, R², MAPE and generates diagnostic plots.
"""

import os
import json
import logging
from typing import Dict, Any, List
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import root_mean_squared_error, mean_absolute_error, r2_score

logger = logging.getLogger(__name__)

FIGURES_DIR = os.path.join("reports", "figures")
os.makedirs(FIGURES_DIR, exist_ok=True)


def calculate_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> Dict[str, float]:
    """Computes comprehensive regression metrics."""
    # Ensure positive predictions for volatility
    y_pred_clipped = np.clip(y_pred, a_min=0.01, a_max=None)
    y_true_clipped = np.clip(y_true, a_min=0.01, a_max=None)

    rmse = float(root_mean_squared_error(y_true, y_pred_clipped))
    mae = float(mean_absolute_error(y_true, y_pred_clipped))
    r2 = float(r2_score(y_true, y_pred_clipped))
    mape = float(np.mean(np.abs((y_true_clipped - y_pred_clipped) / y_true_clipped)) * 100.0)

    return {
        "RMSE": round(rmse, 4),
        "MAE": round(mae, 4),
        "R2": round(r2, 4),
        "MAPE": round(mape, 2),
    }


def plot_model_comparison(results: Dict[str, Dict[str, Dict[str, float]]], output_path: str):
    """Generates bar chart comparing RMSE, MAE, and R2 across models on test set."""
    models = list(results.keys())
    rmse_vals = [results[m]["test"]["RMSE"] for m in models]
    mae_vals = [results[m]["test"]["MAE"] for m in models]
    r2_vals = [results[m]["test"]["R2"] for m in models]

    x = np.arange(len(models))
    width = 0.25

    fig, ax1 = plt.subplots(figsize=(10, 6))

    ax1.bar(x - width, rmse_vals, width, label="RMSE (lower is better)", color="#1f77b4")
    ax1.bar(x, mae_vals, width, label="MAE (lower is better)", color="#ff7f0e")
    ax1.set_ylabel("Error Metric (Annualized Volatility Ratio)")
    ax1.set_xticks(x)
    ax1.set_xticklabels([m.replace("_", " ") for m in models], rotation=15, ha="right")

    ax2 = ax1.twinx()
    ax2.plot(x + width, r2_vals, color="#2ca02c", marker="o", linewidth=2.5, label="R² Score (higher is better)")
    ax2.set_ylabel("R² Score")

    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines1 + lines2, labels1 + labels2, loc="upper right", frameon=True)

    plt.title("Model Performance Benchmark Comparison on Unseen 2022 Test Set", fontsize=13, pad=12)
    plt.tight_layout()
    fig.savefig(output_path, dpi=200)
    plt.close(fig)


def plot_feature_importance(model: Any, feature_names: List[str], output_path: str, top_n: int = 15):
    """Plots top N most important features from tree-based models."""
    if hasattr(model, "feature_importances_"):
        importances = model.feature_importances_
    else:
        logger.warning("Model does not provide feature_importances_ attribute.")
        return

    feat_imp = pd.Series(importances, index=feature_names).sort_values(ascending=False).head(top_n)

    fig, ax = plt.subplots(figsize=(10, 6))
    sns.barplot(x=feat_imp.values, y=feat_imp.index, palette="viridis", ax=ax)
    ax.set_title(f"Top {top_n} Predictive Features for Cryptocurrency Volatility", fontsize=14, pad=10)
    ax.set_xlabel("Relative Feature Importance Score")
    ax.set_ylabel("Feature Name")
    plt.tight_layout()
    fig.savefig(output_path, dpi=200)
    plt.close(fig)


def plot_predictions_vs_actual(
    y_test: np.ndarray,
    y_pred: np.ndarray,
    dates: pd.Series,
    coin_name: str,
    output_path: str
):
    """Plots predicted vs actual volatility over time for a selected asset and scatter fit."""
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))

    # Time series comparison
    ax1.plot(dates, y_test, label="Actual Realized Volatility", color="#1f77b4", alpha=0.8, linewidth=1.5)
    ax1.plot(dates, y_pred, label="Predicted Volatility (XGBoost)", color="#d62728", linestyle="--", linewidth=1.5)
    ax1.set_title(f"{coin_name}: Actual vs Predicted 7-Day Volatility (Test Set)", fontsize=12)
    ax1.set_xlabel("Date")
    ax1.set_ylabel("Annualized Volatility")
    ax1.legend(frameon=True)

    # Scatter plot
    ax2.scatter(y_test, y_pred, alpha=0.3, color="#2ca02c", s=15)
    min_val = min(float(np.min(y_test)), float(np.min(y_pred)))
    max_val = max(float(np.max(y_test)), float(np.max(y_pred)))
    ax2.plot([min_val, max_val], [min_val, max_val], color="red", linestyle="--", label="Perfect Fit (y = x)")
    ax2.set_title("Predicted vs Actual Scatter Fit", fontsize=12)
    ax2.set_xlabel("Actual Volatility")
    ax2.set_ylabel("Predicted Volatility")
    ax2.legend(frameon=True)

    plt.tight_layout()
    fig.savefig(output_path, dpi=200)
    plt.close(fig)


def plot_residuals(y_test: np.ndarray, y_pred: np.ndarray, output_path: str):
    """Plots distribution of prediction residuals (errors)."""
    residuals = y_test - y_pred
    fig, ax = plt.subplots(figsize=(8, 5))
    sns.histplot(residuals, bins=50, kde=True, color="#9467bd", ax=ax)
    ax.axvline(0, color="black", linestyle="--", linewidth=1.2)
    ax.axvline(np.mean(residuals), color="red", linestyle=":", label=f"Mean Error: {np.mean(residuals):.3f}")
    ax.set_title("Residual Error Distribution (Actual - Predicted)", fontsize=13)
    ax.set_xlabel("Prediction Residual")
    ax.legend(frameon=True)
    plt.tight_layout()
    fig.savefig(output_path, dpi=200)
    plt.close(fig)
