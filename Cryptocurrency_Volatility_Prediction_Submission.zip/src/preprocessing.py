"""
Preprocessing Module for Cryptocurrency Historical Prices.
Handles missing values, anomaly cleaning, bounds validation, and dataset preparation.
"""

import logging
import numpy as np
import pandas as pd
from typing import Optional

logger = logging.getLogger(__name__)


def clean_and_preprocess(
    df: pd.DataFrame,
    min_history_days: int = 60,
    fill_strategy: str = "forward_backward"
) -> pd.DataFrame:
    """
    Cleans and preprocesses the raw cryptocurrency DataFrame.

    Steps performed:
    1. Removes duplicate records for (crypto_name, date).
    2. Drops rows with invalid/NaN close prices.
    3. Fixes OHLC bounds inconsistencies (e.g. high < low or close outside high/low).
    4. Handles zero or non-positive values for open, low, volume, market_cap.
    5. Filters out cryptocurrencies with fewer than `min_history_days` records.
    6. Interpolates or forward/backward fills missing prices per cryptocurrency group.

    Parameters:
    -----------
    df : pd.DataFrame
        Raw dataset from data_loader.
    min_history_days : int
        Minimum number of historical days required per cryptocurrency.
    fill_strategy : str
        Strategy for missing values within a cryptocurrency series.

    Returns:
    --------
    pd.DataFrame:
        Cleaned and structured DataFrame ready for feature engineering.
    """
    logger.info("Starting data cleaning and preprocessing...")
    initial_rows = len(df)

    # 1. Deduplicate
    df = df.drop_duplicates(subset=["crypto_name", "date"]).copy()
    if len(df) < initial_rows:
        logger.info("Removed %d duplicate rows.", initial_rows - len(df))

    # 2. Sort explicitly
    df = df.sort_values(by=["crypto_name", "date"]).reset_index(drop=True)

    # 3. Drop missing or non-positive close prices
    df = df.dropna(subset=["close"])
    df = df[df["close"] > 0].copy()

    # 4. Handle open, high, low anomalies per coin
    # Replace open <= 0 with previous close or current close
    df.loc[df["open"] <= 0, "open"] = df.loc[df["open"] <= 0, "close"]

    # Ensure High is at least max(Open, Close) and Low is at most min(Open, Close)
    df["high"] = np.maximum(df["high"], np.maximum(df["open"], df["close"]))
    df["low"] = np.minimum(df["low"], np.minimum(df["open"], df["close"]))

    # Low must be strictly positive
    df.loc[df["low"] <= 0, "low"] = np.minimum(df.loc[df["low"] <= 0, "open"], df.loc[df["low"] <= 0, "close"]) * 0.99

    # 5. Handle zero volume and market cap
    # In crypto datasets, early tokens may have missing/zero volume or market_cap.
    # We substitute non-positive values with group-level rolling medians or epsilon.
    def impute_crypto_series(group: pd.DataFrame) -> pd.DataFrame:
        # Forward fill and backward fill any occasional missing values
        group["volume"] = group["volume"].replace(0, np.nan)
        group["market_cap"] = group["market_cap"].replace(0, np.nan)

        if fill_strategy == "forward_backward":
            group["volume"] = group["volume"].ffill().bfill()
            group["market_cap"] = group["market_cap"].ffill().bfill()

        # If entire coin volume/market_cap was zero, assign proxy based on close price
        if group["volume"].isna().all():
            group["volume"] = 1000.0
        else:
            group["volume"] = group["volume"].fillna(group["volume"].median())

        if group["market_cap"].isna().all():
            group["market_cap"] = group["close"] * 1_000_000.0
        else:
            group["market_cap"] = group["market_cap"].fillna(group["market_cap"].median())

        return group

    # Apply imputation per crypto group
    processed_dfs = []
    for _, grp in df.groupby("crypto_name"):
        processed_dfs.append(impute_crypto_series(grp))
    df = pd.concat(processed_dfs, ignore_index=True)

    # Ensure no lingering NaN or zero in critical features
    df["volume"] = np.maximum(df["volume"], 1.0)
    df["market_cap"] = np.maximum(df["market_cap"], 10.0)

    # 6. Filter coins with insufficient trading history
    coin_counts = df.groupby("crypto_name")["date"].count()
    valid_coins = coin_counts[coin_counts >= min_history_days].index
    dropped_coins = set(coin_counts.index) - set(valid_coins)

    if dropped_coins:
        logger.info("Dropping coins with < %d days: %s", min_history_days, dropped_coins)
    df = df[df["crypto_name"].isin(valid_coins)].copy()

    df = df.sort_values(by=["crypto_name", "date"]).reset_index(drop=True)
    logger.info("Preprocessing complete. Remaining rows: %d across %d cryptocurrencies.", len(df), df["crypto_name"].nunique())

    return df


if __name__ == "__main__":
    from src.data_loader import load_raw_data
    raw = load_raw_data()
    clean = clean_and_preprocess(raw)
    print("Clean shape:", clean.shape)
    print("Null count:\n", clean.isnull().sum())
