# ⚡ Cryptocurrency Volatility Prediction System
### An End-to-End Machine Learning System for Forecasting Digital Asset Volatility & Operational Risk

[![Python](https://img.shields.io/badge/Python-3.10%2B-blue.svg)](https://www.python.org/)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![Streamlit](https://img.shields.io/badge/Dashboard-Streamlit-FF4B4B.svg)](https://streamlit.io/)
[![Flask](https://img.shields.io/badge/API-Flask-black.svg)](https://flask.palletsprojects.com/)
[![Tests](https://img.shields.io/badge/Tests-Pytest%20Passing-brightgreen.svg)](tests/)

---

## 📌 1. Project Overview

Cryptocurrency markets are notorious for extreme price swings, liquidity shocks, and abrupt regime changes. Accurately anticipating periods of heightened volatility is essential for:
- **Risk Management & Position Sizing:** Preventing account liquidations and calibrating dynamic Value-at-Risk (VaR).
- **Algorithmic Trading Strategies:** Optimizing dynamic stop-losses and option pricing.
- **DeFi Lending Protocols:** Dynamically adjusting margin requirements and collateral loan-to-value (LTV) ratios.

This project delivers an end-to-end, production-grade Machine Learning system to predict **7-day forward realized volatility** across **55+ cryptocurrencies** using 9 years of historical market data (2013–2022, 72,946 observations).

---

## 🏗️ 2. Repository Structure

```
PW project/
├── data/
│   ├── raw/                      # Raw dataset (dataset.csv, dataset.csv.zip)
│   └── processed/                # Engineered feature matrix (crypto_features.csv)
│
├── src/                          # Modular production source code
│   ├── __init__.py
│   ├── data_loader.py            # Ingestion, extraction & schema validation
│   ├── preprocessing.py          # Cleaning, deduplication, imputation & bounds
│   ├── feature_engineering.py    # Technical indicators, Parkinson/GK vol, ATR, target
│   ├── models.py                 # Baseline, Ridge, Random Forest, XGBoost definitions
│   ├── train.py                  # Temporal split, model training & artifact saving
│   ├── evaluate.py               # Benchmark metrics (RMSE, MAE, R², MAPE) & diagnostic plots
│   ├── predict.py                # Real-time inference engine & risk classification
│   └── generate_eda_plots.py     # Generator for publication-quality EDA figures
│
├── models/                       # Serialized production artifacts
│   ├── best_volatility_model.pkl # Champion Random Forest model
│   ├── scaler.pkl                # Fitted StandardScaler
│   ├── feature_metadata.json     # Feature names & temporal split metadata
│   └── model_metrics.json        # Evaluation scores across all models
│
├── notebooks/                    # Interactive Jupyter notebooks
│   ├── 01_exploratory_data_analysis.ipynb
│   └── 02_feature_engineering_and_modeling.ipynb
│
├── reports/                      # Reports and generated graphics
│   ├── figures/                  # 10 publication-quality charts (EDA & Evaluation)
│   ├── EDA_Report.md             # In-depth Exploratory Data Analysis report
│   └── Final_Project_Report.md   # Executive final project report
│
├── docs/                         # Engineering & architectural documentation
│   ├── HLD.md                    # High-Level Design document
│   ├── LLD.md                    # Low-Level Design document
│   └── Pipeline_Architecture.md  # End-to-end data pipeline architecture
│
├── app/                          # Deployment interfaces
│   ├── streamlit_app.py          # Interactive Streamlit analytics dashboard
│   └── flask_api.py              # RESTful microservice API
│
├── tests/                        # Automated unit and integration tests
│   ├── test_preprocessing.py
│   ├── test_feature_engineering.py
│   └── test_model_inference.py
│
├── requirements.txt              # Project dependencies
├── run_pipeline.py               # Master CLI execution pipeline
└── README.md                     # Comprehensive project documentation
```

---

## ⚡ 3. Key Features & Innovations

1. **Multi-Scale Financial Feature Engineering:**
   - **Extreme Range Estimators:** Parkinson High-Low volatility and Garman-Klass OHLC volatility.
   - **Trend & Volatility Squeeze:** Bollinger Bandwidth, %B, and Normalized ATR (NATR-14).
   - **Liquidity Shocks:** Turnover velocity ($\text{Volume}/\text{MarketCap}$) and 7-day volume spike ratios.
   - **Momentum:** RSI-14, Normalized MACD, and Price-to-Moving Average ratios ($C/\text{SMA}_7 - 1$, $C/\text{SMA}_{30} - 1$).
2. **Leakage-Free Temporal Partitioning:**
   - **Train:** 2013–2020 ($N=48,460$)
   - **Validation:** 2021 ($N=15,225$)
   - **Test:** 2022 ($N=7,335$) — strict out-of-time evaluation during the 2022 market downturn.
3. **Four-Tier Operational Risk Engine:**
   - 🟢 **Low Risk:** $\sigma < 50\%$ (Calm regime)
   - 🟡 **Moderate Risk:** $50\% \le \sigma < 85\%$ (Typical market baseline)
   - 🟠 **High Risk:** $85\% \le \sigma < 130\%$ (Elevated risk; wider stop-losses advised)
   - 🔴 **Extreme Risk:** $\sigma \ge 130\%$ (Liquidation turbulence regime)
4. **Interactive Local Deployments:**
   - **Streamlit Web Dashboard:** Interactive asset picker, forecast visualizer, and What-If Scenario Simulator.
   - **Flask Microservice:** RESTful API with automated health checks and JSON endpoints.

---

## 📊 4. Benchmark Performance Results

| Model Architecture | Test RMSE (Lower is better) | Test MAE (Lower is better) | Test $R^2$ (Higher is better) | Test MAPE (%) |
|---|---|---|---|---|
| **Naive Persistence Baseline** | 1.9317 | 0.6178 | -5.0930 | 50.80% |
| **Ridge Regression** | 0.8007 | 0.4895 | -0.0468 | 221.49% |
| **XGBoost Regressor** | 0.7010 | 0.4850 | 0.1976 | 144.18% |
| **Random Forest (Champion)** | **0.6846** | **0.4581** | **0.2346** | **41.44%** |

> **Key Result:** The champion **Random Forest** model reduced test prediction error by over **64%** compared to the naive financial persistence benchmark.

---

## 🚀 5. Installation & Quick Start

### 5.1 Clone & Setup Environment
```bash
# Clone the repository
git clone <repo-url>
cd "PW project"

# Install dependencies
pip install -r requirements.txt
```

### 5.2 Run the End-to-End Pipeline
Execute the full data ingestion, cleaning, feature engineering, EDA generation, model training, evaluation, and inference validation in a single command:
```bash
python run_pipeline.py
```

### 5.3 Run Unit Tests
```bash
pytest tests/ -v
```

---

## 💻 6. Running Local Deployments

### Option A: Streamlit Interactive Web Application
Launch the visual web dashboard:
```bash
streamlit run app/streamlit_app.py
```
Open [http://localhost:8501](http://localhost:8501) in your browser. Features included:
- **⚡ Real-Time Volatility Forecast:** Select any of the 55 cryptos to view the 7-day predicted volatility and risk tier.
- **🎛️ Scenario Simulator:** Interactively adjust ATR, RSI, Parkinson Volatility, and Volume Turnover to simulate market turbulence.
- **📊 Model Benchmarks & Importance:** View comparative metrics and feature importance charts.
- **📈 Historical EDA Explorer:** High-resolution market dynamics gallery.

### Option B: Flask RESTful Microservice API
Launch the API server:
```bash
python app/flask_api.py
```
Default URL: `http://localhost:5000`

#### Example API Endpoints:
- **Health Check:**
  ```bash
  curl http://localhost:5000/health
  ```
- **List All Cryptocurrencies:**
  ```bash
  curl http://localhost:5000/api/cryptos
  ```
- **Predict for a Specific Asset:**
  ```bash
  curl http://localhost:5000/api/predict/Bitcoin
  ```
  *Response:*
  ```json
  {
    "status": "success",
    "data": {
      "crypto_name": "Bitcoin",
      "latest_date": "2022-09-19",
      "close_price": 19544.13,
      "predicted_volatility_annualized": 0.9091,
      "predicted_volatility_pct": "90.91%",
      "predicted_daily_volatility_pct": "4.76%",
      "risk_level": "High",
      "risk_description": "Elevated risk regime; wider stop-losses advised"
    }
  }
  ```
- **Custom Feature Prediction (POST):**
  ```bash
  curl -X POST http://localhost:5000/api/predict/custom \
       -H "Content-Type: application/json" \
       -d "{\"rolling_vol_7d\": 0.85, \"natr_14\": 7.5, \"bb_bandwidth\": 0.35, \"rsi_14\": 42.0}"
  ```

---

## 📚 7. Project Documentation Index

- **[Exploratory Data Analysis Report](reports/EDA_Report.md):** Detailed analysis of volatility clustering, distributions, and correlation matrices.
- **[High-Level Design (HLD)](docs/HLD.md):** Architectural topology, subsystem responsibilities, and non-functional requirements.
- **[Low-Level Design (LLD)](docs/LLD.md):** Mathematical formulas, class diagrams, schemas, and component interfaces.
- **[Pipeline Architecture](docs/Pipeline_Architecture.md):** Ingestion, feature flow, temporal splitting, and model registry lifecycle.
- **[Final Project Report](reports/Final_Project_Report.md):** Comprehensive findings, empirical benchmarks, and quantitative trading insights.

---

## 👥 8. Submission Checklist (PW Skills Requirements)

- [x] **Source Code:** Modular, clean, PEP-8 compliant scripts in `src/`, `app/`, `tests/`
- [x] **EDA Report:** Complete summary and figures in `reports/EDA_Report.md` & `reports/figures/`
- [x] **HLD & LLD Documents:** In `docs/HLD.md` and `docs/LLD.md`
- [x] **Pipeline Architecture Document:** In `docs/Pipeline_Architecture.md`
- [x] **Final Report:** In `reports/Final_Project_Report.md`
- [x] **Trained Model & Metrics:** In `models/best_volatility_model.pkl` & `models/model_metrics.json`
- [x] **Local Deployment:** Streamlit app (`app/streamlit_app.py`) & Flask API (`app/flask_api.py`)
- [x] **Jupyter Notebooks:** In `notebooks/01_exploratory_data_analysis.ipynb` & `notebooks/02_feature_engineering_and_modeling.ipynb`
